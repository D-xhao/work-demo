$(function() {
				share();
			});

			function share() {
				window._bd_share_config = {
					"common": {
						"bdSnsKey": {},
						"bdText": "",
						"bdMini": "2",
						"bdMiniList": false,
						"bdPic": "",
						"bdStyle": "0",
						"bdSize": "16"
					},
					"share": {},
					"slide": { // 跟图标式的代码相比，这里是添加了浮窗式 slide 属性配置
						"type": "slide",
						"bdImg": "5",
						"bdPos": "left",
						"bdTop": "100"
					}
				};
				window._bd_share_config = {
					share: [{
						"bdSize": 16
					}],
				}
				with(document) 0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion=' + ~(-new Date() / 36e5)];
			}