var LR_FODH='fb0ac946c0bc1403191406f28516858b4b0178aa1f9cdca95cebc41f828ca172106e453258b5f5b1dccec3cfccc567f0ff9a9f2c7355b400511a812648d37abe';eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36)) }; if (!''.replace(/^/, String)) { while (c--) d[e(c)] = k[c] || e(c); k = [function (e) { return d[e] }]; e = function () { return '\\w+' }; c = 1 }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p }('7 4(1){3 2("5();",6(1),0,0)}', 8, 8, '|s|Fsw3B|return|Hwd8F9|LR_GETDATA_DES_FUNCTION|Fcw5O|function'.split('|'), 0, {})); function Fsw3B(beinetkey, message, encrypt, mode, iv) { var spfunction1 = new Array(0x1010400, 0, 0x10000, 0x1010404, 0x1010004, 0x10404, 0x4, 0x10000, 0x400, 0x1010400, 0x1010404, 0x400, 0x1000404, 0x1010004, 0x1000000, 0x4, 0x404, 0x1000400, 0x1000400, 0x10400, 0x10400, 0x1010000, 0x1010000, 0x1000404, 0x10004, 0x1000004, 0x1000004, 0x10004, 0, 0x404, 0x10404, 0x1000000, 0x10000, 0x1010404, 0x4, 0x1010000, 0x1010400, 0x1000000, 0x1000000, 0x400, 0x1010004, 0x10000, 0x10400, 0x1000004, 0x400, 0x4, 0x1000404, 0x10404, 0x1010404, 0x10004, 0x1010000, 0x1000404, 0x1000004, 0x404, 0x10404, 0x1010400, 0x404, 0x1000400, 0x1000400, 0, 0x10004, 0x10400, 0, 0x1010004); var spfunction2 = new Array(-0x7fef7fe0, -0x7fff8000, 0x8000, 0x108020, 0x100000, 0x20, -0x7fefffe0, -0x7fff7fe0, -0x7fffffe0, -0x7fef7fe0, -0x7fef8000, -0x80000000, -0x7fff8000, 0x100000, 0x20, -0x7fefffe0, 0x108000, 0x100020, -0x7fff7fe0, 0, -0x80000000, 0x8000, 0x108020, -0x7ff00000, 0x100020, -0x7fffffe0, 0, 0x108000, 0x8020, -0x7fef8000, -0x7ff00000, 0x8020, 0, 0x108020, -0x7fefffe0, 0x100000, -0x7fff7fe0, -0x7ff00000, -0x7fef8000, 0x8000, -0x7ff00000, -0x7fff8000, 0x20, -0x7fef7fe0, 0x108020, 0x20, 0x8000, -0x80000000, 0x8020, -0x7fef8000, 0x100000, -0x7fffffe0, 0x100020, -0x7fff7fe0, -0x7fffffe0, 0x100020, 0x108000, 0, -0x7fff8000, 0x8020, -0x80000000, -0x7fefffe0, -0x7fef7fe0, 0x108000); var spfunction3 = new Array(0x208, 0x8020200, 0, 0x8020008, 0x8000200, 0, 0x20208, 0x8000200, 0x20008, 0x8000008, 0x8000008, 0x20000, 0x8020208, 0x20008, 0x8020000, 0x208, 0x8000000, 0x8, 0x8020200, 0x200, 0x20200, 0x8020000, 0x8020008, 0x20208, 0x8000208, 0x20200, 0x20000, 0x8000208, 0x8, 0x8020208, 0x200, 0x8000000, 0x8020200, 0x8000000, 0x20008, 0x208, 0x20000, 0x8020200, 0x8000200, 0, 0x200, 0x20008, 0x8020208, 0x8000200, 0x8000008, 0x200, 0, 0x8020008, 0x8000208, 0x20000, 0x8000000, 0x8020208, 0x8, 0x20208, 0x20200, 0x8000008, 0x8020000, 0x8000208, 0x208, 0x8020000, 0x20208, 0x8, 0x8020008, 0x20200); var spfunction4 = new Array(0x802001, 0x2081, 0x2081, 0x80, 0x802080, 0x800081, 0x800001, 0x2001, 0, 0x802000, 0x802000, 0x802081, 0x81, 0, 0x800080, 0x800001, 0x1, 0x2000, 0x800000, 0x802001, 0x80, 0x800000, 0x2001, 0x2080, 0x800081, 0x1, 0x2080, 0x800080, 0x2000, 0x802080, 0x802081, 0x81, 0x800080, 0x800001, 0x802000, 0x802081, 0x81, 0, 0, 0x802000, 0x2080, 0x800080, 0x800081, 0x1, 0x802001, 0x2081, 0x2081, 0x80, 0x802081, 0x81, 0x1, 0x2000, 0x800001, 0x2001, 0x802080, 0x800081, 0x2001, 0x2080, 0x800000, 0x802001, 0x80, 0x800000, 0x2000, 0x802080); var spfunction5 = new Array(0x100, 0x2080100, 0x2080000, 0x42000100, 0x80000, 0x100, 0x40000000, 0x2080000, 0x40080100, 0x80000, 0x2000100, 0x40080100, 0x42000100, 0x42080000, 0x80100, 0x40000000, 0x2000000, 0x40080000, 0x40080000, 0, 0x40000100, 0x42080100, 0x42080100, 0x2000100, 0x42080000, 0x40000100, 0, 0x42000000, 0x2080100, 0x2000000, 0x42000000, 0x80100, 0x80000, 0x42000100, 0x100, 0x2000000, 0x40000000, 0x2080000, 0x42000100, 0x40080100, 0x2000100, 0x40000000, 0x42080000, 0x2080100, 0x40080100, 0x100, 0x2000000, 0x42080000, 0x42080100, 0x80100, 0x42000000, 0x42080100, 0x2080000, 0, 0x40080000, 0x42000000, 0x80100, 0x2000100, 0x40000100, 0x80000, 0, 0x40080000, 0x2080100, 0x40000100); var spfunction6 = new Array(0x20000010, 0x20400000, 0x4000, 0x20404010, 0x20400000, 0x10, 0x20404010, 0x400000, 0x20004000, 0x404010, 0x400000, 0x20000010, 0x400010, 0x20004000, 0x20000000, 0x4010, 0, 0x400010, 0x20004010, 0x4000, 0x404000, 0x20004010, 0x10, 0x20400010, 0x20400010, 0, 0x404010, 0x20404000, 0x4010, 0x404000, 0x20404000, 0x20000000, 0x20004000, 0x10, 0x20400010, 0x404000, 0x20404010, 0x400000, 0x4010, 0x20000010, 0x400000, 0x20004000, 0x20000000, 0x4010, 0x20000010, 0x20404010, 0x404000, 0x20400000, 0x404010, 0x20404000, 0, 0x20400010, 0x10, 0x4000, 0x20400000, 0x404010, 0x4000, 0x400010, 0x20004010, 0, 0x20404000, 0x20000000, 0x400010, 0x20004010); var spfunction7 = new Array(0x200000, 0x4200002, 0x4000802, 0, 0x800, 0x4000802, 0x200802, 0x4200800, 0x4200802, 0x200000, 0, 0x4000002, 0x2, 0x4000000, 0x4200002, 0x802, 0x4000800, 0x200802, 0x200002, 0x4000800, 0x4000002, 0x4200000, 0x4200800, 0x200002, 0x4200000, 0x800, 0x802, 0x4200802, 0x200800, 0x2, 0x4000000, 0x200800, 0x4000000, 0x200800, 0x200000, 0x4000802, 0x4000802, 0x4200002, 0x4200002, 0x2, 0x200002, 0x4000000, 0x4000800, 0x200000, 0x4200800, 0x802, 0x200802, 0x4200800, 0x802, 0x4000002, 0x4200802, 0x4200000, 0x200800, 0, 0x2, 0x4200802, 0, 0x200802, 0x4200000, 0x800, 0x4000002, 0x4000800, 0x800, 0x200002); var spfunction8 = new Array(0x10001040, 0x1000, 0x40000, 0x10041040, 0x10000000, 0x10001040, 0x40, 0x10000000, 0x40040, 0x10040000, 0x10041040, 0x41000, 0x10041000, 0x41040, 0x1000, 0x40, 0x10040000, 0x10000040, 0x10001000, 0x1040, 0x41000, 0x40040, 0x10040040, 0x10041000, 0x1040, 0, 0, 0x10040040, 0x10000040, 0x10001000, 0x41040, 0x40000, 0x41040, 0x40000, 0x10041000, 0x1000, 0x40, 0x10040040, 0x1000, 0x41040, 0x10001000, 0x40, 0x10000040, 0x10040000, 0x10040040, 0x10000000, 0x40000, 0x10001040, 0, 0x10041040, 0x40040, 0x10000040, 0x10040000, 0x10001000, 0x10001040, 0, 0x10041040, 0x41000, 0x41000, 0x1040, 0x1040, 0x40040, 0x10000000, 0x10041000); var keys = E2e7vf(beinetkey); var m = 0, i, j, temp, temp2, right1, right2, left, right, looping; var cbcleft, cbcleft2, cbcright, cbcright2; var endloop, loopinc; var len = message.length; var chunk = 0; var iterations = keys.length == 32 ? 3 : 9; if (iterations == 3) { looping = encrypt ? new Array(0, 32, 2) : new Array(30, -2, -2) } else { looping = encrypt ? new Array(0, 32, 2, 62, 30, -2, 64, 96, 2) : new Array(94, 62, -2, 32, 64, 2, 30, -2, -2) }; message += '\0\0\0\0\0\0\0\0'; result = ''; tempresult = ''; if (mode == 1) { cbcleft = (iv.charCodeAt(m++) << 24) | (iv.charCodeAt(m++) << 16) | (iv.charCodeAt(m++) << 8) | iv.charCodeAt(m++); cbcright = (iv.charCodeAt(m++) << 24) | (iv.charCodeAt(m++) << 16) | (iv.charCodeAt(m++) << 8) | iv.charCodeAt(m++); m = 0 } while (m < len) { if (encrypt) { left = (message.charCodeAt(m++) << 16) | message.charCodeAt(m++); right = (message.charCodeAt(m++) << 16) | message.charCodeAt(m++) } else { left = (message.charCodeAt(m++) << 24) | (message.charCodeAt(m++) << 16) | (message.charCodeAt(m++) << 8) | message.charCodeAt(m++); right = (message.charCodeAt(m++) << 24) | (message.charCodeAt(m++) << 16) | (message.charCodeAt(m++) << 8) | message.charCodeAt(m++) }; if (mode == 1) { if (encrypt) { left ^= cbcleft; right ^= cbcright } else { cbcleft2 = cbcleft; cbcright2 = cbcright; cbcleft = left; cbcright = right } }; temp = ((left >>> 4) ^ right) & 0x0f0f0f0f; right ^= temp; left ^= (temp << 4); temp = ((left >>> 16) ^ right) & 0x0000ffff; right ^= temp; left ^= (temp << 16); temp = ((right >>> 2) ^ left) & 0x33333333; left ^= temp; right ^= (temp << 2); temp = ((right >>> 8) ^ left) & 0x00ff00ff; left ^= temp; right ^= (temp << 8); temp = ((left >>> 1) ^ right) & 0x55555555; right ^= temp; left ^= (temp << 1); left = ((left << 1) | (left >>> 31)); right = ((right << 1) | (right >>> 31)); for (j = 0; j < iterations; j += 3) { endloop = looping[j + 1]; loopinc = looping[j + 2]; for (i = looping[j]; i != endloop; i += loopinc) { right1 = right ^ keys[i]; right2 = ((right >>> 4) | (right << 28)) ^ keys[i + 1]; temp = left; left = right; right = temp ^ (spfunction2[(right1 >>> 24) & 0x3f] | spfunction4[(right1 >>> 16) & 0x3f] | spfunction6[(right1 >>> 8) & 0x3f] | spfunction8[right1 & 0x3f] | spfunction1[(right2 >>> 24) & 0x3f] | spfunction3[(right2 >>> 16) & 0x3f] | spfunction5[(right2 >>> 8) & 0x3f] | spfunction7[right2 & 0x3f]) }; temp = left; left = right; right = temp }; left = ((left >>> 1) | (left << 31)); right = ((right >>> 1) | (right << 31)); temp = ((left >>> 1) ^ right) & 0x55555555; right ^= temp; left ^= (temp << 1); temp = ((right >>> 8) ^ left) & 0x00ff00ff; left ^= temp; right ^= (temp << 8); temp = ((right >>> 2) ^ left) & 0x33333333; left ^= temp; right ^= (temp << 2); temp = ((left >>> 16) ^ right) & 0x0000ffff; right ^= temp; left ^= (temp << 16); temp = ((left >>> 4) ^ right) & 0x0f0f0f0f; right ^= temp; left ^= (temp << 4); if (mode == 1) { if (encrypt) { cbcleft = left; cbcright = right } else { left ^= cbcleft2; right ^= cbcright2 } }; if (encrypt) { tempresult += String.fromCharCode((left >>> 24), ((left >>> 16) & 0xff), ((left >>> 8) & 0xff), (left & 0xff), (right >>> 24), ((right >>> 16) & 0xff), ((right >>> 8) & 0xff), (right & 0xff)) } else { tempresult += String.fromCharCode(((left >>> 16) & 0xffff), (left & 0xffff), ((right >>> 16) & 0xffff), (right & 0xffff)) }; encrypt ? chunk += 16 : chunk += 8; if (chunk == 512) { result += tempresult; tempresult = ''; chunk = 0 } }; return result + tempresult }; function E2e7vf(beinetkey) { pc2bytes0 = new Array(0, 0x4, 0x20000000, 0x20000004, 0x10000, 0x10004, 0x20010000, 0x20010004, 0x200, 0x204, 0x20000200, 0x20000204, 0x10200, 0x10204, 0x20010200, 0x20010204); pc2bytes1 = new Array(0, 0x1, 0x100000, 0x100001, 0x4000000, 0x4000001, 0x4100000, 0x4100001, 0x100, 0x101, 0x100100, 0x100101, 0x4000100, 0x4000101, 0x4100100, 0x4100101); pc2bytes2 = new Array(0, 0x8, 0x800, 0x808, 0x1000000, 0x1000008, 0x1000800, 0x1000808, 0, 0x8, 0x800, 0x808, 0x1000000, 0x1000008, 0x1000800, 0x1000808); pc2bytes3 = new Array(0, 0x200000, 0x8000000, 0x8200000, 0x2000, 0x202000, 0x8002000, 0x8202000, 0x20000, 0x220000, 0x8020000, 0x8220000, 0x22000, 0x222000, 0x8022000, 0x8222000); pc2bytes4 = new Array(0, 0x40000, 0x10, 0x40010, 0, 0x40000, 0x10, 0x40010, 0x1000, 0x41000, 0x1010, 0x41010, 0x1000, 0x41000, 0x1010, 0x41010); pc2bytes5 = new Array(0, 0x400, 0x20, 0x420, 0, 0x400, 0x20, 0x420, 0x2000000, 0x2000400, 0x2000020, 0x2000420, 0x2000000, 0x2000400, 0x2000020, 0x2000420); pc2bytes6 = new Array(0, 0x10000000, 0x80000, 0x10080000, 0x2, 0x10000002, 0x80002, 0x10080002, 0, 0x10000000, 0x80000, 0x10080000, 0x2, 0x10000002, 0x80002, 0x10080002); pc2bytes7 = new Array(0, 0x10000, 0x800, 0x10800, 0x20000000, 0x20010000, 0x20000800, 0x20010800, 0x20000, 0x30000, 0x20800, 0x30800, 0x20020000, 0x20030000, 0x20020800, 0x20030800); pc2bytes8 = new Array(0, 0x40000, 0, 0x40000, 0x2, 0x40002, 0x2, 0x40002, 0x2000000, 0x2040000, 0x2000000, 0x2040000, 0x2000002, 0x2040002, 0x2000002, 0x2040002); pc2bytes9 = new Array(0, 0x10000000, 0x8, 0x10000008, 0, 0x10000000, 0x8, 0x10000008, 0x400, 0x10000400, 0x408, 0x10000408, 0x400, 0x10000400, 0x408, 0x10000408); pc2bytes10 = new Array(0, 0x20, 0, 0x20, 0x100000, 0x100020, 0x100000, 0x100020, 0x2000, 0x2020, 0x2000, 0x2020, 0x102000, 0x102020, 0x102000, 0x102020); pc2bytes11 = new Array(0, 0x1000000, 0x200, 0x1000200, 0x200000, 0x1200000, 0x200200, 0x1200200, 0x4000000, 0x5000000, 0x4000200, 0x5000200, 0x4200000, 0x5200000, 0x4200200, 0x5200200); pc2bytes12 = new Array(0, 0x1000, 0x8000000, 0x8001000, 0x80000, 0x81000, 0x8080000, 0x8081000, 0x10, 0x1010, 0x8000010, 0x8001010, 0x80010, 0x81010, 0x8080010, 0x8081010); pc2bytes13 = new Array(0, 0x4, 0x100, 0x104, 0, 0x4, 0x100, 0x104, 0x1, 0x5, 0x101, 0x105, 0x1, 0x5, 0x101, 0x105); var iterations = beinetkey.length >= 24 ? 3 : 1; var keys = new Array(32 * iterations); var shifts = new Array(0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0); var lefttemp, righttemp, m = 0, n = 0, temp; for (var j = 0; j < iterations; j++) { left = (beinetkey.charCodeAt(m++) << 24) | (beinetkey.charCodeAt(m++) << 16) | (beinetkey.charCodeAt(m++) << 8) | beinetkey.charCodeAt(m++); right = (beinetkey.charCodeAt(m++) << 24) | (beinetkey.charCodeAt(m++) << 16) | (beinetkey.charCodeAt(m++) << 8) | beinetkey.charCodeAt(m++); temp = ((left >>> 4) ^ right) & 0x0f0f0f0f; right ^= temp; left ^= (temp << 4); temp = ((right >>> -16) ^ left) & 0x0000ffff; left ^= temp; right ^= (temp << -16); temp = ((left >>> 2) ^ right) & 0x33333333; right ^= temp; left ^= (temp << 2); temp = ((right >>> -16) ^ left) & 0x0000ffff; left ^= temp; right ^= (temp << -16); temp = ((left >>> 1) ^ right) & 0x55555555; right ^= temp; left ^= (temp << 1); temp = ((right >>> 8) ^ left) & 0x00ff00ff; left ^= temp; right ^= (temp << 8); temp = ((left >>> 1) ^ right) & 0x55555555; right ^= temp; left ^= (temp << 1); temp = (left << 8) | ((right >>> 20) & 0x000000f0); left = (right << 24) | ((right << 8) & 0xff0000) | ((right >>> 8) & 0xff00) | ((right >>> 24) & 0xf0); right = temp; for (i = 0; i < shifts.length; i++) { if (shifts[i]) { left = (left << 2) | (left >>> 26); right = (right << 2) | (right >>> 26) } else { left = (left << 1) | (left >>> 27); right = (right << 1) | (right >>> 27) }; left &= -0xf; right &= -0xf; lefttemp = pc2bytes0[left >>> 28] | pc2bytes1[(left >>> 24) & 0xf] | pc2bytes2[(left >>> 20) & 0xf] | pc2bytes3[(left >>> 16) & 0xf] | pc2bytes4[(left >>> 12) & 0xf] | pc2bytes5[(left >>> 8) & 0xf] | pc2bytes6[(left >>> 4) & 0xf]; righttemp = pc2bytes7[right >>> 28] | pc2bytes8[(right >>> 24) & 0xf] | pc2bytes9[(right >>> 20) & 0xf] | pc2bytes10[(right >>> 16) & 0xf] | pc2bytes11[(right >>> 12) & 0xf] | pc2bytes12[(right >>> 8) & 0xf] | pc2bytes13[(right >>> 4) & 0xf]; temp = ((righttemp >>> 16) ^ lefttemp) & 0x0000ffff; keys[n++] = lefttemp ^ temp; keys[n++] = righttemp ^ (temp << 16) } }; return keys }; function Fcw5O(s) { var r = ''; for (var i = 0; i < s.length; i += 2) { var sxx = parseInt(s.substring(i, i + 2), 16); r += String.fromCharCode(sxx) }; return r }; function daf723b97b6() { eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36)) }; if (!''.replace(/^/, String)) { while (c--) d[e(c)] = k[c] || e(c); k = [function (e) { return d[e] }]; e = function () { return '\\w+' }; c = 1 }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p }('z j$=["\\A\\r\\m\\s\\m\\s\\N\\A\\k","\\k\\p\\o\\y","\\H\\m\\r\\T\\p\\o\\y","\\C\\k\\q\\R\\s\\y","\\o\\p\\C\\C","\\y\\p\\u\\Q\\P\\q\\Y\\r\\m\\A\\k\\r\\s\\N","\\W\\p\\A",\'\\m\\U\\V\\k\\o\\s\',"\\y\\p\\u\\y\\k\\r","\\u\\o\\r\\k\\k\\q\\F\\r\\k\\u\\m\\C\\J\\s\\w\\m\\q","\\u\\r","\\u\\o\\r\\k\\k\\q\\F\\m\\r\\w\\k\\q\\s\\p\\s\\w\\m\\q","\\u\\m","\\o\\p\\q\\G\\p\\u","\\o\\u","\\w\\k\\F\\p\\o\\s\\w\\G\\k\\K","\\w\\k\\K",\'\\H\\J\\q\\o\\s\\w\\m\\q\'];z a,b;a=I[j$[0]].X;b=I[j$[0]].1c;t[j$[1]]=E(c,d,e){n(c===L){x};n(a&&c[j$[2]]===a){c[j$[2]](d,e)}D n(c[j$[3]]===+c[j$[3]]){M(z f=S,l=c[j$[3]];f<l;f++){n(d[j$[4]](e,c[f],f,c)==={})x}}D{M(z f 1b c){n(c[j$[5]](f)){n(d[j$[4]](e,c[f],f,c)==={})x}}}};t[j$[6]]=E(c,d,e){z f=[];n(c==L)x f;n(b&&c[j$[6]]===b)x c[j$[6]](d,e);t[j$[1]](c,E(g,h,i){f[f[j$[3]]]=d[j$[4]](e,g,h,i)});x f};v={19:B,1a:B,18:B,Z:B};n(O v==j$[7]){t[j$[8]]=v[j$[8]];t[j$[9]]=v[j$[10]];t[j$[11]]=v[j$[12]];t[j$[13]]=v[j$[14]];t[j$[15]]=v[j$[16]]}D n(O v==j$[17]){t[j$[8]]=v}', 62, 75, '|||||||||||||||||||_|x65||x6f|if|x63|x61|x6e|x72|x74|this|x73|opts|x69|return|x68|var|x70|true|x6c|else|function|x5f|x76|x66|Array|x75|x78|null|for|x79|typeof|x77|x4f|x67|0x0|x45|x62|x6a|x6d|forEach|x50|iex|||||||||cs|sr|so|in|map'.split('|'), 0, {})) }; eval(function (p, a, c, k, e, d) { e = function (c) { return (c < a ? "" : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36)) }; if (!''.replace(/^/, String)) { while (c--) d[e(c)] = k[c] || e(c); k = [function (e) { return d[e] }]; e = function () { return '\\w+' }; c = 1; }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p; }('N l$=["\\z\\r\\p\\n\\p\\n\\Q\\z\\m","\\z\\y\\u\\B","\\y\\u\\m\\r\\U\\w\\m\\s\\n","\\q\\o\\s\\w\\y\\o\\w\\m","\\v\\p\\q\\p\\r\\W\\m\\z\\n\\B","\\u\\v\\r\\m\\m\\s\\1k\\r\\m\\u\\p\\q\\y\\n\\t\\p\\s","\\w\\m\\n\\H\\v\\r\\m\\m\\s\\S\\m\\u\\p\\q\\y\\n\\t\\p\\s",\'\\y\\s\\D\\m\\E\\t\\s\\m\\D\',"\\2g\\p\\t\\s",\'\\P\',"\\w\\m\\n\\1i\\t\\J\\m\\2n\\p\\s\\m\\1z\\E\\E\\u\\m\\n","\\B\\o\\u\\H\\m\\u\\u\\t\\p\\s\\H\\n\\p\\r\\o\\w\\m","\\B\\o\\u\\1M\\p\\v\\o\\q\\H\\n\\p\\r\\o\\w\\m","\\B\\o\\u\\1v\\s\\D\\m\\P\\W\\1b","\\D\\p\\v\\y\\J\\m\\s\\n","\\1b\\p\\D\\Q","\\o\\D\\D\\1F\\m\\B\\o\\O\\t\\p\\r","\\p\\z\\m\\s\\W\\o\\n\\o\\1b\\o\\u\\m","\\v\\z\\y\\I\\q\\o\\u\\u","\\z\\q\\o\\n\\E\\p\\r\\J","\\D\\p\\1J\\p\\n\\1i\\r\\o\\v\\R","\\w\\m\\n\\M\\q\\y\\w\\t\\s\\u\\H\\n\\r\\t\\s\\w","\\v\\o\\s\\O\\o\\u","\\t\\u\\I\\o\\s\\O\\o\\u\\H\\y\\z\\z\\p\\r\\n\\m\\D","\\w\\m\\n\\I\\o\\s\\O\\o\\u\\1f\\t\\s\\w\\m\\r\\z\\r\\t\\s\\n","\\B\\o\\u\\B\\m\\r",\'\\1a\\1a\\1a\',\'\',"\\q\\m\\s\\w\\n\\B","\\J\\y\\r\\J\\y\\r\\B\\o\\u\\B\\1p\\1k\\1p\\Y\\1k\\w\\v",\'\\1a\\1a\\1a\',\'\',\'\\1d\',"\\v\\B\\o\\r\\I\\p\\D\\m\\U\\n","\\q\\p\\v\\o\\q\\H\\n\\p\\r\\o\\w\\m","\\u\\m\\u\\u\\t\\p\\s\\H\\n\\p\\r\\o\\w\\m","\\t\\s\\D\\m\\P\\m\\D\\W\\1F","\\v\\r\\m\\o\\n\\m\\1w\\q\\m\\J\\m\\s\\n",\'\\v\\o\\s\\O\\o\\u\',"\\w\\m\\n\\I\\p\\s\\n\\m\\P\\n",\'\\Y\\D\',"\\o\\z\\z\\1J\\o\\J\\m",\'\\2d\\t\\v\\r\\p\\u\\p\\E\\n\\G\\1v\\s\\n\\m\\r\\s\\m\\n\\G\\1w\\P\\z\\q\\p\\r\\m\\r\',\'\\1J\\m\\n\\u\\v\\o\\z\\m\',"\\n\\m\\u\\n","\\t\\u\\1v\\1w","\\t\\m\\1k\\o\\v\\n\\t\\O\\m\\P","\\w\\m\\n\\1v\\1w\\M\\q\\y\\w\\t\\s\\u\\H\\n\\r\\t\\s\\w","\\w\\m\\n\\S\\m\\w\\y\\q\\o\\r\\M\\q\\y\\w\\t\\s\\u\\H\\n\\r\\t\\s\\w","\\J\\o\\z","\\z\\q\\y\\w\\t\\s\\u","\\n\\Q\\z\\m","\\u\\y\\E\\E\\t\\P\\m\\u",\'\\2v\',\'\\1n\',"\\s\\o\\J\\m","\\D\\m\\u\\v\\r\\t\\z\\n\\t\\p\\s",\'\\1O\\1O\',\'\\1W\',"\\U\\v\\n\\t\\O\\m\\1s\\1z\\1b\\2g\\m\\v\\n",\'\\H\\B\\p\\v\\R\\1I\\o\\O\\m\\1f\\q\\o\\u\\B\\L\\H\\B\\p\\v\\R\\1I\\o\\O\\m\\1f\\q\\o\\u\\B\',\'\\U\\v\\r\\p\\M\\W\\1f\\L\\M\\W\\1f\',\'\\M\\W\\1f\\L\\M\\D\\E\\I\\n\\r\\q\',\'\\2a\\y\\t\\v\\R\\1i\\t\\J\\m\\L\\2a\\y\\t\\v\\R\\1i\\t\\J\\m\',\'\\r\\J\\p\\v\\P\\L\\S\\m\\o\\q\\M\\q\\o\\Q\\m\\r\\G\\2f\\Y\\G\\I\\p\\s\\n\\r\\p\\q\',\'\\r\\J\\p\\v\\P\\L\\S\\m\\o\\q\\M\\q\\o\\Q\\m\\r\\G\\2f\\Y\\G\\I\\p\\s\\n\\r\\p\\q\\L\\1x\',\'\\S\\m\\o\\q\\M\\q\\o\\Q\\m\\r\\L\\S\\m\\o\\q\\M\\q\\o\\Q\\m\\r\\1h\\n\\J\\1l\\G\\U\\v\\n\\t\\O\\m\\1s\\G\\I\\p\\s\\n\\r\\p\\q\\G\\1h\\1p\\Y\\2h\\1b\\t\\n\\1l\',\'\\S\\m\\o\\q\\2e\\t\\D\\m\\p\\L\\S\\m\\o\\q\\2e\\t\\D\\m\\p\\1h\\n\\J\\1l\\G\\U\\v\\n\\t\\O\\m\\1s\\G\\I\\p\\s\\n\\r\\p\\q\\G\\1h\\1p\\Y\\2h\\1b\\t\\n\\1l\',\'\\S\\m\\o\\q\\M\\q\\o\\Q\\m\\r\',\'\\H\\1C\\I\\n\\q\\L\\H\\1C\\I\\n\\q\',\'\\1C\\2d\\M\\q\\o\\Q\\m\\r\\L\\1z\\I\\1s\',\'\\U\\w\\I\\p\\s\\n\\r\\p\\q\\L\\U\\w\\I\\p\\s\\n\\r\\p\\q\',\'\\H\\R\\Q\\z\\m\\L\\W\\m\\n\\m\\v\\n\\t\\p\\s\',\'\\1W\',"","\\u\\v\\r\\m\\m\\s\\1k\\p\\r\\t\\m\\s\\n\\o\\n\\t\\p\\s","\\B\\m\\t\\w\\B\\n","\\1I\\t\\D\\n\\B",\'\\v\\o\\s\\O\\o\\u\',\'\\Y\\D\',\'\\E\\R\\y\\E\\R\\y\\E\\R\\y\\E\\R\\y\\E\\R\\y\',"\\n\\m\\P\\n\\1F\\o\\u\\m\\q\\t\\s\\m","\\n\\p\\z","\\E\\p\\s\\n","\\1x\\1H\\z\\P\\G\\2b\\U\\r\\t\\o\\q\\2b","\\o\\q\\z\\B\\o\\1b\\m\\n\\t\\v","\\E\\t\\q\\q\\H\\n\\Q\\q\\m","\\1a\\E\\1H\\1d","\\E\\t\\q\\q\\S\\m\\v\\n","\\1a\\1d\\1H\\2s","\\E\\t\\q\\q\\1i\\m\\P\\n","\\r\\w\\1b\\o\\1h\\1x\\1d\\Y\\1n\\G\\Y\\1d\\2t\\1n\\G\\1d\\1n\\G\\1d\\L\\2q\\1l","\\n\\p\\W\\o\\n\\o\\2r\\S\\1M"];2u[l$[0]]={g:K(){N a=[];a[l$[1]](Z[l$[2]]);a[l$[1]](Z[l$[3]]);a[l$[1]](X[l$[4]]);T(A[l$[5]]){N b=A[l$[6]]();T(1t b!==l$[7]){a[l$[1]](b[l$[8]](l$[9]))}};a[l$[1]](2c 2x()[l$[10]]());a[l$[1]](A[l$[11]]());a[l$[1]](A[l$[12]]());a[l$[1]](A[l$[13]]());T(V[l$[14]][l$[15]]){a[l$[1]](1t(V[l$[14]][l$[15]][l$[16]]))}1g{a[l$[1]](1t 2y)};a[l$[1]](1t(V[l$[17]]));a[l$[1]](Z[l$[18]]);a[l$[1]](Z[l$[19]]);a[l$[1]](Z[l$[20]]);a[l$[1]](A[l$[21]]());T(A[l$[22]]&&A[l$[23]]()){a[l$[1]](A[l$[24]]())};T(A[l$[25]]){N b=A[l$[25]](a[l$[8]](l$[26]),1Q)+l$[27];1y(b[l$[28]]<1T){b+=1u};x b}1g{N b=A[l$[29]](a[l$[8]](l$[26]),1Q)+l$[27];1y(b[l$[28]]<1T){b+=l$[32]};x b}},2w:K(a,b){N c,d,e,f,h,i,j,k;c=a[l$[28]]&2j;d=a[l$[28]]-c;e=b;h=2p;i=2k;k=1u;1y(k<d){j=((a[l$[33]](k)&1e))|((a[l$[33]](++k)&1e)<<1P)|((a[l$[33]](++k)&1e)<<C)|((a[l$[33]](++k)&1e)<<2o);++k;j=((((j&F)*h)+((((j>>>C)*h)&F)<<C)))&1c;j=(j<<1D)|(j>>>1B);j=((((j&F)*i)+((((j>>>C)*i)&F)<<C)))&1c;e^=j;e=(e<<1V)|(e>>>2l);f=((((e&F)*1Y)+((((e>>>C)*1Y)&F)<<C)))&1c;e=(((f&F)+2m)+((((f>>>C)+3r)&F)<<C))};j=1u;3o(c){1G 2j:j^=(a[l$[33]](k+1E)&1e)<<C;1G 1E:j^=(a[l$[33]](k+1K)&1e)<<1P;1G 1K:j^=(a[l$[33]](k)&1e);j=(((j&F)*h)+((((j>>>C)*h)&F)<<C))&1c;j=(j<<1D)|(j>>>1B);j=(((j&F)*i)+((((j>>>C)*i)&F)<<C))&1c;e^=j};e^=a[l$[28]];e^=e>>>C;e=(((e&F)*1U)+((((e>>>C)*1U)&F)<<C))&1c;e^=e>>>1V;e=((((e&F)*1S)+((((e>>>C)*1S)&F)<<C)))&1c;e^=e>>>C;x e>>>1u},3g:K(){1o{x!!V[l$[34]]}1r(e){x 1j}},3x:K(){1o{x!!V[l$[35]]}1r(e){x 1j}},2H:K(){1o{x!!V[l$[36]]}1r(e){x 1j}},2C:K(){N a=V[l$[14]][l$[37]](l$[38]);x!!(a[l$[39]]&&a[l$[39]](l$[1X]))},2z:K(){T(Z[l$[1N]]===l$[2A]){x 1j}1g T(Z[l$[1N]]===l$[2F]&&/2G/[l$[2D]](Z[l$[2]])){x 1j};x 2Q},3a:K(){T(A[l$[3q]]()&&A[l$[30]]){x A[l$[31]]()}1g{x A[l$[3e]]()}},3f:K(){x A[l$[1L]](Z[l$[3c]],K(a){N b=A[l$[1L]](a,K(c){x[c[l$[3d]],c[l$[2Z]]][l$[8]](l$[2T])})[l$[8]](l$[2U]);x[a[l$[2R]],a[l$[2S]],b][l$[8]](l$[2X])},A)[l$[8]](l$[1Z])},2Y:K(){T(V[l$[2V]]){N a=[l$[2W],l$[3b],l$[2E],l$[2B],l$[2N],l$[2M],l$[2P],l$[2O],l$[2J],l$[2I],l$[2L],l$[2K],l$[3A]];x A[l$[1L]](a,K(b){1o{2c 3B(b);x b}1r(e){x 3C}})[l$[8]](l$[1Z])}1g{x l$[3z]}},3w:K(){N a;T(A[l$[3y]]){a=(X[l$[1q]]>X[l$[1m]])?[X[l$[1q]],X[l$[1m]]]:[X[l$[1m]],X[l$[1q]]]}1g{a=[X[l$[1q]],X[l$[1m]]]};x a},3F:K(){N a=V[l$[14]][l$[37]](l$[38]);N b=a[l$[39]](l$[1X]);N c=l$[3E];b[l$[2i]]=l$[3D];b[l$[3l]]=l$[3k];b[l$[2i]]=l$[3n];b[l$[1A]]=l$[3m];b[l$[3h]](3j,1K,3i,3t);b[l$[1A]]=l$[3s];b[l$[1R]](c,1E,1D);b[l$[1A]]=l$[3v];b[l$[1R]](c,3u,1B);x a[l$[3p]]()}};', 62, 228, '|||||||||||||||||||||_|x65|x74|x61|x6f|x6c|x72|x6e|x69|x73|x63|x67|return|x75|x70|this|x68|0x10|x64|x66|0xffff|x20|x53|x43|x6d|function|x2e|x50|var|x76|x78|x79|x6b|x52|if|x41|window|x44|screen|x32|navigator|||||||||||x23|x62|0xffffffff|x30|0xff|x46|else|x28|x54|true|x5f|x29|77|x2c|try|x33|76|catch|x58|typeof|0x0|x49|x45|x31|while|x4f|86|0x11|x57|0xf|0x2|x42|case|x36|x77|x4e|0x1|49|x4c|41|x3a|0x8|0x1f|90|0xc2b2ae35|0x20|0x85ebca6b|0xd|x3b|40|0x5|58|||||||||||x51|x27|new|x4d|x56|x47|x6a|x2d|81|0x3|0x1b873593|0x13|0x6b64|x7a|0x18|0xcc9e2d51|x37|x55|x39|x34|daf723b97b6|x7e|murmurhash3_32_gc|Date|undefined|isIE|42|63|isCanvasSupported|44|62|43|Trident|hasIndexDb|69|68|71|70|65|64|67|66|false|55|56|53|54|59|60|57|getIEPluginsString|52|46|47|||||||||getPluginsString|61|50|51|48|getRegularPluginsString|hasLocalStorage|88|0x3e|0x7d|84|83|87|85|switch|92|45|0xe654|89|0x14|0x4|91|getScreenResolution|hasSessionStorage|75|74|72|ActiveXObject|null|82|80|getCanvasFingerprint'.split('|'), 0, {}));var LR_Tick='55907577ea3544c79791cd79cdac5811';
var LR_ssl = 1;
var LR_websiteid = 'DUT92615367';
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=1(0);',2,2,'LR_FODH|Hwd8F9'.split('|'),0,{}));var LR_lng = 'cn';
var LR_js_pm = 'd';
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.2(/3/1,\'6\').2(/5/1,\'4\');',7,7,'LR_FODH|g|replace|b|d|B|C'.split('|'),0,{}));if(typeof(LR_showfloat)=='undefined' || LR_showfloat!=1)var LR_showfloat = 1;
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.2(/3/1,\'6\').2(/5/1,\'4\');',7,7,'LR_FODH|g|replace|C|B|F|D'.split('|'),0,{}));var LR_siteid = '92615367';
var LR_imgurl = 'https://dut.zoosnet.net/';
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.2(/3/1,\'6\').2(/5/1,\'4\');',7,7,'LR_FODH|g|replace|w|p|q|W'.split('|'),0,{}));eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.2(/3/1,\'6\').2(/5/1,\'4\');',7,7,'LR_FODH|g|replace|H|h|G|f'.split('|'),0,{}));eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.2(/3/1,\'6\').2(/5/1,\'4\');',7,7,'LR_FODH|g|replace|A|G|D|c'.split('|'),0,{}));var LR_isMobile = 0;
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.2(/3/1,\'6\').2(/5/1,\'4\');',7,7,'LR_FODH|g|replace|U|G|r|w'.split('|'),0,{}));var LR_sysurl = 'https://dut.zoosnet.net/';
var LiveReceptionCode_isonline = 1;
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.3(/1/2,\'5\').3(/6/2,\'4\');',7,7,'LR_FODH||g|replace|o|X|P'.split('|'),0,{}));eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('0=0.1(/2/3,\'5\').1(/4/3,\'2\');',6,6,'LR_FODH|replace|D|g|F|v'.split('|'),0,{}));var lr_para2 = LR_FODH,lr_para0 = '10|31|6|15|1|14|5|27|0|30|13|2|26|7|23|8|22|12|19|4|20|18|9|25|28|17|16|3|21|11|29|24',lr_para1 = '',lr_para3 = '',lr_para4 = '';eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('2=1 0().3();6=5.4("|");',7,7,'daf723b97b6|new|lr_para1|g|split|lr_para0|lr_para4'.split('|'),0,{}));eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('3 1$=["\\4\\6\\8\\4\\9\\7"];5(3 a=b;a<f;a++){g+=e[1$[0]](a,2)+c[1$[0]](d[a],2)}',17,17,'|_|0x1|var|x73|for|x75|x72|x62|x74||0x0|lr_para2|lr_para4|lr_para1|0x20|lr_para3'.split('|'),0,{}));if(typeof(LR_cid) == 'undefined')
{
	var LR_robot='https://lrbot.zoosnet.net/lr.aspx';
	if(LiveReceptionCode_isonline)LR_robot='';
	if(!LiveReceptionCode_isonline)LR_robot='';
	var _lr_issupport_track= 1;
	LR_hasInstall=0;
	var LR_ivite_img='JS/tj_blue/p.gif';
	var LR_invite_color0='#8DC4EB';
	var LR_invite_color1='#E1EFFC';
	var LR_invite_color2='#A7C5E3';
	var LR_invite_color3='#000000';
	var LR_accept_img='js/tj_blue/a_cn.gif';
	var LR_refuse_img='js/tj_blue/r_cn.gif';
	var LR_close_img='js/tj_blue/close.gif';
	var _lr_invitetitle=unescape("%u60a8%u597d%uff0c%u6765%u81ea%25IP%25%u7684%u670b%u53cb");
	var _lr_invitestring=unescape("%3cP style%3d%22FONT-SIZE%3a 9pt%22%3e%u60a8%u597d%uff0c%u6b22%u8fce%u60a8%uff01%3cBR%3e%3cBR%3e%u5982%u679c%u60a8%u6709%u4efb%u4f55%u95ee%u9898%uff0c%u8bf7%u63a5%u53d7%u6b64%u9080%u8bf7%uff0c%u6211%u4f1a%u7ed9%u4f60%u66f4%u591a%u66f4%u597d%u7684%u534f%u52a9%uff01%3c%2fP%3e");
	var _lr_invite_interval=0;
	var offline_invite_hidden=1;
	var LR_invite_hide_float=1;
	var LR_hidden_region='';
	var LR_repeatinvite=1;
	var LR_defineregion=0;
	var LR_invitesearchkey=0;
	var LR_invitestring1_auto=unescape("");
	var LR_auto_pagetitle=0;
	var LR_issupport_feydj=0;
	var LR_chated_no_invite=0;
	var LR_userurl0=0;
	var LR_invite_display_kind=0;
	var LR_fade_invite=0;
	var LR_confirm_closechat=unescape("%u60a8%u6b63%u5728%u8fdb%u884c%u5728%u7ebf%u5bf9%u8bdd%uff0c%u786e%u5b9a%u8981%u7ed3%u675f%u5bf9%u8bdd%u5417%uff1f");
	var LR_pm001=1;
	var LR_pm013=400;
	var LR_pm014=400;
	var LR_pm015=0;
	if('1'=='1'){LR_showfloat=0;}
	var _lr_helpsrc_on=unescape("http://dut.zoosnet.net/site/92615367/onlineimgsrc_cn.png");
	var _lr_helpalt_on=unescape("%u5982%u679c%u60a8%u6709%u4ec0%u4e48%u95ee%u9898%2c%u8bf7%u70b9%u51fb%u6b64%u5904%u8fdb%u884c%u5373%u65f6%u6c9f%u901a%3b");
	var _lr_helpsrc_of=unescape("http%3a%2f%2fdut.zoosnet.net%2flr%2fimages%2foffline_cn3.gif");
	var _lr_helpalt_of=unescape("%u6ca1%u6709%u5ba2%u670d%u4eba%u5458%u5728%u7ebf%2c%u8bf7%u70b9%u51fb%u6b64%u5904%u7559%u8a00!%u6211%u4eec%u4f1a%u5c3d%u5feb%u7b54%u590d%3b");
	var _lr_closesrc0='7.gif';
	var _lr_toright=((typeof(LiveReceptionCode_ToRight)!='undefined')?LiveReceptionCode_ToRight:0);
	var _lr_left=((typeof(LiveReceptionCode_helpimgleft)!='undefined')?LiveReceptionCode_helpimgleft:0);
	var _lr_tobottom=((typeof(LiveReceptionCode_ToBottom)!='undefined')?LiveReceptionCode_ToBottom:0);
	var _lr_top=((typeof(LiveReceptionCode_helpimgtop)!='undefined')?LiveReceptionCode_helpimgtop:150);
	var _lr_mfloat_toright=1;
	var LR_pm012=30;
	var LR_pm011=0;
	var LR_pm007=1;
	if(typeof(LR_showminiDivtimeout)=='undefined')var LR_showminiDivtimeout=1;
	var LR_pm006='#5ba4ed';
	var LR_pm004=1;
	var _lr_mfloat_tobottom=1;
	var _lr_mfloat_imgleft=0;
	var _lr_mfloat_imgtop=0;
	var LR_pm002=1;
	var LR_pm003=0;
	var LR_UserInviteDiv=null;
function LR_SetCookie(name,value,minutes)
{
	if (name.indexOf(LR_websiteid)==-1){name='N'+LR_websiteid+name;}
	var exp  = new Date();
	exp.setTime(exp.getTime() + minutes*60*1000);
	document.cookie = name + '='+ escape (value) + ';'+getRDomain()+'path=/;expires=' + exp.toGMTString();
}
function LR_getCookie(name)
{
	if (name.indexOf(LR_websiteid)==-1){
	var arr = document.cookie.match(new RegExp('(^| )'+'N'+LR_websiteid+name+'=([^;]*)(;|$)'));
	if(arr != null) return unescape(arr[2]);
	}
	var arr = document.cookie.match(new RegExp('(^| )'+name+'=([^;]*)(;|$)'));
	if(arr != null) return unescape(arr[2]);
	if(name=='LiveWS'+LR_websiteid)
	{
		LR_SetCookie(name,LR_Tick,2628000);
		return LR_Tick;
	}
	if(name=='LiveWS'+LR_websiteid+'sessionid')
	{
		LR_SetCookie(name,LR_Tick,720);
		return LR_Tick;
	}
	return null;
}
function getRDomain(){var d,a=location.hostname,b='',c=['.com','.co','.cn','.vn','.info','.net','.org','.me','.mobi','.us','.biz','.top','.xxx','.ca','.co.jp','.js.cn','.com.cn','.net.cn','.org.cn','.gov.cn','.cq.cn','.bj.cn','.zj.cn','.gd.cn','.hn.cn','.hl.cn','.sh.cn','.hb.cn','.ac.cn','.edu.cn','.mx','.tv','.ws','.ag','.com.ag','.net.ag','.org.ag','.am','.asia','.at','.be','.com.br','.net.br','.bz','.com.bz','.net.bz','.cc','.com.vn','.com.co','.net.co','.nom.co','.de','.es','.com.es','.nom.es','.org.es','.eu','.fm','.fr','.gs','.in','.co.in','.firm.in','.gen.in','.ind.in','.net.in','.org.in','.it','.jobs','.jp','.ms','.com.mx','.nl','.nu','.co.nz','.net.nz','.org.nz','.se','.tc','.tk','.tw','.com.tw','.com.hk','.idv.tw','.org.tw','.hk','.co.uk','.me.uk','.org.uk','.vg','.name'];return c=c.join('|').replace('.','\\.'),d=new RegExp('\\.?([^.]+('+c+'))$'),a.replace(d,function(a,c){b=c}),''!=b?'domain=.'+b+';':b}
var LR_cookie_test=1;function LR_cookie_test1() {LR_SetCookie('LR_cookie_t0',1,0.05);LR_cookie_test=(LR_getCookie('LR_cookie_t0')!=null);}LR_cookie_test1();
if(typeof(LR_hasInstall) == 'undefined')
{
	var LR_hasInstall=0;
	var MM_contentVersion = 8;
	var plugin = (navigator.mimeTypes && navigator.mimeTypes["application/x-shockwave-flash"]) ? navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin : 0;
	if (plugin)
	{
		var words = navigator.plugins["Shockwave Flash"].description.split(" ");
		for (var i = 0; i < words.length; ++i)
		{
			if (isNaN(parseInt(words[i])))
				continue;
			var MM_PluginVersion = words[i];
		}
		if(MM_PluginVersion >= MM_contentVersion)LR_hasInstall = 1;
	}
	else if( navigator.userAgent && navigator.userAgent.indexOf("MSIE")>=0 && (navigator.appVersion.indexOf("Win") != -1) )
	{
	try{
		document.write('<SCR' + 'IPT LANGUAGE=VBScript\> \n');
		document.write('on error resume next \n');
		document.write('LR_hasInstall = ( IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash." & MM_contentVersion)))\n');
		document.write('</SCR' + 'IPT\> \n');
	}catch(e){}
		if(LR_hasInstall)LR_hasInstall=2;
	}
	if(window.location.protocol!='http:' && window.location.protocol!='https:')LR_hasInstall=0;
	if(LR_cookie_test && LR_getCookie('LR_hasInstall')=='0'){LR_hasInstall=0;}

}
if(LR_ssl){_lr_helpsrc_on=_lr_helpsrc_on.replace('http://','https://');_lr_helpsrc_of=_lr_helpsrc_of.replace('http://','https://');_lr_closesrc0=_lr_closesrc0.replace('http://','https://');LR_ivite_img=LR_ivite_img.replace('http://','https://');}function LR_addnew0(){
if(_lr_issupport_track)
{
var data='jid='+LR_js_pm+'&id='+LR_siteid+'&sid='+LR_sid+'&cid='+LR_cid+'&lng='+LR_lng;
	data+='&p='+escape(location.href)+'&r='+lr_refer5237+'&e='+escape(LR_explain)+'&FPDH=CGBD&FQDI=CHBD&GRDI=DIBE&CKFM='+ lr_para3 + '&s=' + LR_sSize;
	if(typeof(LR_username)!='undefined'){data+='&un='+escape(LR_username);}
	if(typeof(LR_userdata)!='undefined'){data+='&ud='+escape(LR_userdata);}
	if(typeof(LR_pagetitle)!='undefined'){data+='&pt='+escape(LR_pagetitle);}
	if(LR_issupport_feydj){data+='&f=1';}
checkcount=-1;LR_inviteimgJS=0;LR_hcloopJS(LR_sysurl+'js/JS_Float.aspx',data);LR_explain='';
}else{LR_sidexists=2;}
}
		var minichathtml1=(typeof(minichathtml)!='function');if(minichathtml1)document.write('<link href="https://dut.zoosnet.net/js/JS5.css" rel="stylesheet" type="text/css" />');
function if_src(){if(/rv:11.0;|SE 2.X MetaSr 1.0/.test(navigator.userAgent)) {return '';}return 'src=\"about:blank\"';}
var LR_MCount1 = 5000;

function LR_CheckUserUrl(_url) {
	if (_url == null) {
		return '';
	}
	if (_url.indexOf('//') == -1) {
		return LR_imgurl + _url;
	}
	if (LR_sysurl.substring(0, LR_sysurl.indexOf('//')) == 'http:') {
		return _url.replace(LR_sysurl, LR_imgurl).replace('https://', 'http://');
	} else {
		return _url.replace('http://', 'https://');
	}
}
var LR_cid = null;
var LR_sid = null;
var LR_msg = '';
var LR_fistvisitetime = null;
var LR_visitetime = new Date().getTime();
var LR_lastvisitetime = null;
var LR_visitecounts = 0;
LR_visitepages = 0;
var LR_ip = null;
var LR_ip1 = null;
var LR_ip2 = null;
var LR_showinvite = 1;
var LR_invite0 = '';
var LR_invite1 = null;
var LR_sidexists = -1;
var LR_lastinvite = new Date().getTime();
var checkcount = 0;
var LR_inviteimgJS = 1;
var LR_chatkind = -1;
var lr_refer5237 = escape(document.referrer);
if (typeof(lr_refer5236) != 'undefined') lr_refer5237 = escape(lr_refer5236);
var LR_cname = null;
var LR_ccolor = null;
var LR_lastoname = null;
var LR_nexttimerID = null;
var LR_istate = 0,
	LR_gstate = 0;
var LR_skey = null;
var LR_surl = null;
var LR_ClientEnd = 1;
var LR_cur_invite = null;
var LR_cookie_ctick = 0;
var LR_maxoid = 0;
var lastshowmini = 0;
var lr_newcount = 0;
var LR_sSize = screen.width + '*' + screen.height;

function LR_GetObj(id, theDoc) {
	if (!theDoc) {
		theDoc = document;
	}
	if (theDoc.getElementById) {
		return theDoc.getElementById(id);
	} else if (document.all) {
		return theDoc.all(id);
	}
}
var LR_m_d = null;

function LR_m_e(p1, p2, p3) {
	if (LR_m_d != null) return null;
	var div = document.createElement('DIV');
	div.id = 'LR_m_h_' + new Date().getTime();
	with(div.style) {
		zIndex = 8998;
		top = '0px';
		left = '0px';
		width = '100%';
		height = '100%';
		border = 'none';
		margin = padding = 0;
		position = 'absolute';
		backgroundColor = '#000';
		opacity = '0.2';
		filter = 'alpha(opacity=20)';
		duration = 1000;
	}
	document.body.insertBefore(div, document.body.firstChild);
	if (!p3) LR_m_a('SELECT');
	if (!p2) LR_m_a('OBJECT');
	if (!p1) LR_m_a('IFRAME');
	LR_m_c(div);
	return div;
}

function LR_m_c(obj) {
	obj.style.width = '100%';
	obj.style.height = '100%';
	var bodyCW = 0,
		bodyCH = 0;
	if (document.documentElement && document.documentElement.clientWidth) {
		bodyCW = document.documentElement.clientWidth;
	} else if (window.innerWidth) {
		bodyCW = window.innerWidth;
	} else if (document.body) {
		bodyCW = document.body.clientWidth;
	}
	if (window.innerHeight) bodyCH = window.innerHeight;
	else if (document.documentElement && document.documentElement.clientHeight) bodyCH = document.documentElement.clientHeight;
	else if (document.body) bodyCH = document.body.clientHeight;
	setTimeout(function() {
		bodyCW = Math.max(document.body.scrollWidth, bodyCW);
		bodyCH = Math.max(document.body.scrollHeight, bodyCH);
		obj.style.width = bodyCW + 'px';
		obj.style.height = bodyCH + 'px';
	}, 1);
}

function LR_m_b(TagName) {
	var s = document.getElementsByTagName(TagName);
	for (var i = 0, n = s.length; i < n; i++) {
		if (s[i].id == 'LR_Flash') continue;
		s[i].style.visibility = s[i].getAttribute('LR_m_g');
		s[i].removeAttribute('LR_m_g');
	}
};

function LR_m_a(TagName) {
	var s = document.getElementsByTagName(TagName);
	for (var i = 0, n = s.length; i < n; i++) {
		if (s[i].id == 'LR_Flash') continue;
		s[i].setAttribute('LR_m_g', s[i].style.visibility, 0);
		s[i].style.visibility = 'hidden';
	}
};

function LR_m_f(obj, p1, p2, p3) {
	if (LR_m_d == null) return;
	try {
		if (obj) {
			document.body.removeChild(obj);
			LR_m_d = null;
			if (!p3) LR_m_b('SELECT');
			if (!p2) LR_m_b('OBJECT');
			if (!p1) LR_m_b('IFRAME');
		}
	} catch (e) {}
};
if (LR_auto_pagetitle && typeof(LR_pagetitle) == 'undefined') {
	var LR_pagetitle = document.title;
}
if (typeof(LiveReceptionCode_need_help_html) != 'undefined') LR_showfloat = 1;
if (typeof(LR_explain) == 'undefined') {
	LR_explain = '';
	if (typeof(LiveReception_explain) != 'undefined') {
		LR_explain = unescape(LiveReception_explain);
	}
	if (typeof(LiveReceptionCode_chatexplain_online) != 'undefined') {
		LR_explain = unescape(LiveReceptionCode_chatexplain_online);
	}
}

function LR_minisrc() {
    if (LR_robot != '')
        return LR_robot + '?siteid=' + LR_websiteid + '&sid=' + LR_sid + '&cid=' + LR_cid + '&lng=' + LR_lng + '&keyword=' + LR_skey + '&lastcusname=&webtype=pcmini&p=' + escape(location.href) + '&r=' + lr_refer5237;
    return LR_sysurl + 'LR/' + (LiveReceptionCode_isonline ? (minichathtml1 ? 'minichat_PC' : 'minichat3') : 'minioffline160714') + '.aspx?id=' + LR_websiteid + '&cid=' + LR_cid + '&lng=' + LR_lng + '&sid=' + LR_sid + '&p=' + escape(location.href) + '&r=' + lr_refer5237;
}
function minichathtmlF(islrminimin) { if (!minichathtml1) return minichathtml(islrminimin); return '<div style="' + (LiveReceptionCode_isonline ? 'width:' + LR_pm013 + 'px; height:' + LR_pm014 + 'px;' : 'width:420px; height:463px;') + (islrminimin ? 'display:none;' : '') + '" id="LRMINIWIN"><div  id="LRMINIWIN0" style="z-index: 2147483647; position: absolute; height: 30px; overflow: hidden; display: block;right:0"><span style="float:left;clear:none; width:103px;height:20px; overflow:hidden; margin:0 5px;"></span><span style="' + (LR_pm007 ? '' : 'display:none;') + 'CURSOR:pointer;float:right;clear:none; width:20px;height:20px; margin:6px 2px 0 0; overflow:hidden;" onclick="lr_closemini(1);"><img style="cursor:pointer;" src="' + LR_imgurl + 'lr/mini_new/close.png" border="0"></span><span style="CURSOR:pointer;float:right;overflow:hidden;width:20px;height:20px;clear:none;display:block;margin:6px 2px 0 0;" onclick="lrminiMin();"><img src="' + LR_imgurl + 'lr/mini_new/da1.png" style="cursor:pointer;"  border="0"></span><span style="CURSOR:pointer;float:right;overflow:hidden;width:20px;height:20px;clear:none;display:block;margin:6px 2px 0 0;" onclick="openZoosUrl(\'bchatwin\');lrminiMin();"><img src="' + LR_imgurl + 'lr/mini_new/da.png" style="cursor:pointer;"  border="0"></span><span style="CURSOR:pointer;float:right;overflow:hidden;width:20px;height:20px;clear:none;display:block;margin:6px 2px 0 0;' + (LR_pm015 ?'display:none':'')+'" onclick="lrmove();"><img src="' + LR_imgurl + 'lr/mini_new/jiantou.png" style="cursor:pointer;"  border="0"></span></div><iframe id="LR_miniframe" name="LR_miniframe" width="100%" height="' + (LiveReceptionCode_isonline ? LR_pm014 : '463') + 'px" frameborder="0" scrolling="No" allowtransparency="true" ' + if_src() + '></iframe></div>'; }
        function minibarhtmlF(islrminimin) {if(!minichathtml1)return minibarhtml(islrminimin);return '<div id="LRMINIBar" class="LR_Mini_ICON" style="display:'+(!islrminimin?'none':'block')+';'+(LR_pm011?'left':'right')+': 15px;bottom: '+LR_pm012+'px;" onclick="lrminiMax();"><a class="LR-BTN" style="background-color: '+LR_pm006+';"><span class="LR-ICON LR-ICON-CHAT1" id="LR-BTN-ICON"></span><span id="LR-CIRCLE" style="display:none;background-color: '+LR_pm006+';"></span> </a><div id="LR-BUBBLE" style="display:none;width:400px;'+(LR_pm011?'left:0;':'right: 0;margin-right:34px;')+'cursor:pointer;bottom: '+LR_pm012+'px;"><span class="LR-ICON" id="LR-BUBBLE-CLOSE" onclick="return closebarhtml(event);"></span><div id="LR-BUBBLE-INSIDE"><div id="LR-BUBBLE-title"><img id="LR-BUBBLE-AVATAR" src=""><span id="LR-BUBBLE-NAME"></span></div><div id="LR-BUBBLE-MSG"></div></div></div></div>';}

var IEmsg=(!minichathtml1 || (navigator.appName == "Microsoft Internet Explorer" && /MSIE 6.|MSIE 7.|MSIE 8.|MSIE 9./.test(navigator.userAgent)));
if(minichathtml1)
{
	if(window.addEventListener)
	{
	window.addEventListener('message', function (e) {
            var lr_cmd = e.data;
            if(lr_cmd.a=='hide')
            {
               lrminiMin();return;
            }
            if(lr_cmd.a=='newmsg' && LR_GetObj('LRMINIBar').style.display=='block')
            {
               lr_newcount++;
               var _obj=LR_GetObj('LR-CIRCLE');_obj.innerHTML=lr_newcount;_obj.style.display='block';
               LR_GetObj('LR-BUBBLE-title').style.display=(!lr_cmd.d || !lr_cmd.c)?'none':'block';
               
               LR_GetObj('LR-BUBBLE-MSG').innerHTML=lr_cmd.b;
               LR_GetObj('LR-BUBBLE-AVATAR').src=lr_cmd.c;
               LR_GetObj('LR-BUBBLE').style.display='block';
               LR_GetObj('LR-BUBBLE-NAME').innerHTML=lr_cmd.d;return;
            }
        }, false);
        }
       
        
         function closebarhtml(evt) {
         evt = evt || window.event;
         LR_GetObj('LR-BUBBLE').style.display='none';
            evt.cancelBubble = true;
		    evt.returnValue = false;
		    if (evt.preventDefault && evt.stopPropagation) {
			    evt.preventDefault();
			    evt.stopPropagation();
		    }
		}
        
}


function LR_Check_region() {
	if (LR_defineregion) {
		var invitec0 = unescape(LR_ip1) + ' ' + unescape(LR_ip2);
		if (typeof(only_invite_list) != 'undefined') {
			LR_showinvite = 0;
			var invitec1 = only_invite_list.split('|');
			for (w = 0; w < invitec1.length; w++) {
				if (invitec1[w].length == 0) continue;
				if (invitec0.indexOf(invitec1[w]) != -1) {
					LR_showinvite = 1;
					break;
				}
			}
		} else if (typeof(never_invite_list) != 'undefined') {
			var invitec1 = never_invite_list.split('|');
			for (w = 0; w < invitec1.length; w++) {
				if (invitec1[w].length == 0) continue;
				if (invitec0.indexOf(invitec1[w]) != -1) {
					LR_showinvite = 0;
					break;
				}
			}
		}
	}
	if (LR_hidden_region != '') {
		var lrhgs = LR_hidden_region.split(",");
		var ipfrom = unescape(LR_ip1) + ' ' + unescape(LR_ip2);
		for (w = 0; w < lrhgs.length; w++) {
			if (lrhgs[w] == '') continue;
			if (ipfrom.indexOf(lrhgs[w]) != -1) {
				LR_showinvite = 0;
				return;
			};
		}
		if (LR_showfloat) LR_Floaters[0].showdiv(1);
	}
}

function LR_buildfloat() {
	return (typeof(LiveReceptionCode_need_help_html) != 'undefined') ? LiveReceptionCode_need_help_html : '<img ' + (LiveReceptionCode_isonline ? 'title="' + _lr_helpalt_on + '" alt="' + _lr_helpalt_on + '" src="' + LR_CheckUserUrl(_lr_helpsrc_on) + '"' : 'title="' + _lr_helpalt_of + '" alt="' + _lr_helpalt_of + '" src="' + LR_CheckUserUrl(_lr_helpsrc_of) + '"') + '  style="cursor:pointer" onclick="openZoosUrl(\'chatwin\');">';
}
function LR_checkagent(_lr_na) {
	var _lr_o = _lr_na.split('|');
	for (_lr_w = 0; _lr_w < _lr_o.length; _lr_w++) {
		if (navigator.userAgent.toLowerCase().indexOf(_lr_o[_lr_w]) > -1) return true;
	}
	return false;
}

function LR_check_block(lrobjinner) {
	if (typeof(lrobjinner) == 'undefined') return true;
	lrobjinner = lrobjinner.toLowerCase();
	return ((lrobjinner.indexOf('.gif') == -1 && lrobjinner.indexOf('.jpg') == -1 && lrobjinner.indexOf('.png') == -1 && lrobjinner.indexOf('.swf') == -1 && lrobjinner.indexOf('<iframe') == -1) || lrobjinner.indexOf(' Blocked_') != -1);
}
var LR_Floaters = new Array();
if (typeof(LR_Fid) == 'undefined') {
    var LR_Fid = 0;
    if (typeof (LR_invitew) == 'undefined') {
        var LR_invitew = 211;
        var LR_inviteh = 110;
    }
	var LR_inviteim = new Image;
	
    eval("function OnlinerIcon(){this.pms=new Array();this.LR_scrollTimer=null;this.autoScroll=LR_autoScroll;this.get_tip_str=onliner_get_tip_str;this.start=onliner_start;this.imageTimer=onliner_imageTimer;this.get_close_str=onliner_get_close_str;this.hidden=hidden_div;this.showdiv=show_div;}function LR_autoScroll(){this.imageTimer();}function onliner_get_tip_str(){  var tt = 'z-index:2147483647;position:fixed!important;'+((this.pms['xCenter']==1)?'left:50%;margin-left:-'+this.pms['lr_xCenter']+'px!important;':((this.pms['alignx']==1)?'right':'left')+':'+this.pms['alignW']+'px;')+((this.pms['yCenter']==1)?'top:50%;margin-top:-'+this.pms['lr_yCenter']+'px!important;':((this.pms['aligny']==1)?'bottom':'top')+':'+this.pms['alignH']+'px;')+'_position:absolute;_margin-left:0px;_margin-top:0px;_top:expression(eval(document.compatMode && document.compatMode==\\'CSS1Compat\\')?(documentElement.scrollTop + '+((this.pms['yCenter']==1)?'(document.documentElement.clientHeight-this.offsetHeight)/2':((this.pms['aligny']==1)?'document.documentElement.clientHeight-this.offsetHeight-':'')+this.pms['alignH'])+'):(document.body.scrollTop + '+((this.pms['yCenter']==1)?'(document.body.clientHeight - this.clientHeight)/2':((this.pms['aligny']==1)?'document.body.clientHeight - this.clientHeight-':'')+this.pms['alignH'])+'));_left:expression(eval(document.compatMode && document.compatMode==\\'CSS1Compat\\')?(documentElement.scrollLeft + '+((this.pms['xCenter']==1)?'(document.documentElement.clientWidth-this.offsetWidth)/2':((this.pms['alignx']==1)?'document.documentElement.clientWidth-this.offsetWidth-':'')+this.pms['alignW'])+'):(document.body.scrollLeft + '+((this.pms['xCenter']==1)?'(document.body.clientWidth - this.clientWidth)/2':((this.pms['alignx']==1)?'document.body.clientWidth - this.clientWidth-':'')+this.pms['alignW'])+'));';return tt;}function onliner_get_close_str(){if(this.pms['closer_show']==1) return '<div id=\"swtColse\" style=\"width:20px; height:15px; top:0px; right:0px; position:absolute;background-image: url('+this.pms['closer_img']+');background-repeat: no-repeat;background-position: right top;cursor:pointer;\" onclick=\"LR_Hidemobileinvite('+this.pms['LR_Fid']+');onlinerIcon'+this.pms['LR_Fid']+'.hidden();\"></div>'; return '';}function hidden_div(){this.pms['show']='none';LR_GetObj(this.pms['LRdiv']).style.display='none';}function show_div(showclose){this.pms['show']='block';LR_GetObj(this.pms['LRdiv']).style.display='block';if(LR_GetObj(this.pms['LRfloater']+'close')!=null)LR_GetObj(this.pms['LRfloater']+'close').style.display=showclose?'block':'none';}function onliner_imageTimer(hand){ var _lrobj0=LR_GetObj(this.pms['LRfloater']+'_if');if(_lrobj0!=null){_lrobj0.style.width = _lrobj0.nextSibling.clientWidth+'px';_lrobj0.style.height = _lrobj0.nextSibling.clientHeight+'px';}var _lrobj=LR_GetObj(this.pms['LRdiv']); if(hand || (this.pms['show']=='block' && _lrobj!=null && LR_check_block(_lrobj.innerHTML) && !LR_check_block(this.pms['html']))){var con_img=this.pms['html'];var tt='';if((typeof(LR_above_flash) != 'undefined') && LR_above_flash)tt+='<iframe s'+'r'+'c=\"'+LR_imgurl+'JS/im.html\" id=\"'+this.pms['LRfloater']+'_if\" style=\"position:absolute;z-index:2147483647;top:expression(this.nextSibling.offsetTop);left:expression(this.nextSibling.offsetLeft);width:1px;\" frameborder=\"0\" allowtransparency=\"true\" ></iframe>';tt+='<DIV id=\"'+this.pms['LRfloater']+'\" >'+this.get_close_str()+con_img+'</div>';  _lrobj.innerHTML=tt; LR_GetObj(this.pms['LRfloater']).style.cssText=this.get_tip_str();var _lrobj1=LR_GetObj(this.pms['LRfloater']+'_if');if(_lrobj1!=null){_lrobj1.style.cssText=this.get_tip_str()+'z-index:2147483647;width:expression(this.nextSibling.clientWidth);height:expression(this.nextSibling.clientHeight);';}LR_GetObj(this.pms['LRdiv']).style.display=this.pms['show'];}	}function onliner_start(){	document.write('<div id=\"'+this.pms['LRdiv']+'\" style=\"display:none;\"></div>');}");
} else {
	LR_Fid++;
}
eval('var onlinerIcon' + LR_Fid + '=new OnlinerIcon();');
eval('onlinerIcon' + LR_Fid + '.pms[\'LR_Fid\']=LR_Fid;');
eval('onlinerIcon' + LR_Fid + '.pms[\'show\']=(LR_showfloat && LR_hidden_region.length==0)?\'block\':\'none\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'aligny\']=_lr_tobottom;');
eval('onlinerIcon' + LR_Fid + '.pms[\'alignx\']=_lr_toright;');
eval('onlinerIcon' + LR_Fid + '.pms[\'alignW\']=_lr_left;');
eval('onlinerIcon' + LR_Fid + '.pms[\'alignH\']=_lr_top;');
eval('onlinerIcon' + LR_Fid + '.pms[\'html\']=LR_buildfloat();');
eval('onlinerIcon' + LR_Fid + '.pms[\'closer_show\']=(_lr_closesrc0==\'\')?0:1;');
eval('onlinerIcon' + LR_Fid + '.pms[\'closer_img\']="' + LR_imgurl + 'LR/closeimg/' + _lr_closesrc0 + '";');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRfloater\']=\'LRfloater' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRdiv\']=\'LRdiv' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.start();');
eval('onlinerIcon' + LR_Fid + '.LR_scrollTimer = window.setInterval(\'onlinerIcon' + LR_Fid + '.autoScroll()\', 200); ');
eval('LR_Floaters.push(onlinerIcon' + LR_Fid + ');');
if (!LR_checkagent('ucbrowser') && document.body&&LR_GetObj('LRdiv' + LR_Fid)) document.body.appendChild(LR_GetObj('LRdiv' + LR_Fid));
LR_Fid++;
eval('var onlinerIcon' + LR_Fid + '=new OnlinerIcon();');
eval('onlinerIcon' + LR_Fid + '.pms[\'LR_Fid\']=LR_Fid;');
eval('onlinerIcon' + LR_Fid + '.pms[\'show\']=\'none\';');
if ((typeof(Invite_ToBottom) != 'undefined') && (typeof(Invite_ToRight) != 'undefined') && (typeof(Invite_left) != 'undefined') && (typeof(Invite_top) != 'undefined')) {
	eval('onlinerIcon' + LR_Fid + '.pms[\'aligny\']=Invite_ToBottom;');
	eval('onlinerIcon' + LR_Fid + '.pms[\'alignx\']=Invite_ToRight;');
	eval('onlinerIcon' + LR_Fid + '.pms[\'alignW\']=Invite_left;');
	eval('onlinerIcon' + LR_Fid + '.pms[\'alignH\']=Invite_top;');
} else {
	eval('onlinerIcon' + LR_Fid + '.pms[\'xCenter\']=1;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'yCenter\']=1;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'lr_xCenter\']=(typeof (lr_xCenter) != \'undefined\' ? lr_xCenter : LR_invitew);');
    eval('onlinerIcon' + LR_Fid + '.pms[\'lr_yCenter\']=(typeof (lr_yCenter) != \'undefined\' ? lr_yCenter : LR_inviteh);');
}
eval('onlinerIcon' + LR_Fid + '.pms[\'html\']=\'\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'closer_show\']=0;');
eval('onlinerIcon' + LR_Fid + '.pms[\'closer_img\']="' + LR_sysurl + 'LR/closeimg/' + _lr_closesrc0 + '";');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRfloater\']=\'LRfloater' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRdiv\']=\'LRdiv' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.start();');
eval('onlinerIcon' + LR_Fid + '.LR_scrollTimer = window.setInterval(\'onlinerIcon' + LR_Fid + '.autoScroll()\', 200); ');
eval('LR_Floaters.push(onlinerIcon' + LR_Fid + ');');

function LR_showInviteDiv(h1, h2) {
	if (!LR_showinvite) return;
	if (h1 == null && h2 == null) return;
	if (h1 == '1' && h2 == '1' && LR_chated_no_invite && LR_getCookie('LR_lastchat') == '1') {
		return;
	}
	LR_invitew = 211;LR_inviteh = 110;
	var LR_ikind1 = (!LR_invite_display_kind || h2 == '1');
	if (typeof(LiveAutoInvite0) != 'undefined' && h1 == '1') h1 = LiveAutoInvite0;
	if (h2 == '1') h2 = LR_GetAutoInvite2();
	if (h1.indexOf('%IP%') != -1) {
		var ipfrom = unescape(LR_ip1);
		if (ipfrom.length < 3 || (LR_ip1 == null && LR_ip2 == null)) {
			h1 = '';
		} else {
			h1 = h1.replace('%IP%', ipfrom);
		}
	}
	LR_cur_invite = h2;
	LR_m_f(LR_m_d);
	if ((typeof(LR_invite_m) != 'undefined') && LR_invite_m) LR_m_d = LR_m_e();
	if (LR_UserInviteDiv != null && LR_ikind1) {
		LR_Floaters[1].pms['html'] = LR_UserInviteDiv.replace('{c0}', LR_invite_color0).replace('{c1}', LR_invite_color1).replace('{c2}', LR_invite_color2).replace('{c3}', LR_invite_color3).replace('{aimg}', LR_CheckUserUrl(LR_accept_img)).replace('{fimg}', LR_CheckUserUrl(LR_refuse_img)).replace('{pimg}', LR_CheckUserUrl(LR_ivite_img)).replace('{h1}', h1).replace('{h2}', h2).replace(/\{0\}/g, 'openZoosUrl();LR_HideInvite();').replace(/\{1\}/g, 'LR_RefuseChat();LR_HideInvite();');
	} else {
		onlinerIcon1.pms['closer_show'] = 0;
		
		LR_Floaters[1].pms['html'] = '<table ID="LR_Tb2" style="BORDER-COLLAPSE: collapse; background-color: ' + LR_invite_color1 + ';border: ' + LR_invite_color0 + ' 2px solid;margin:2px;padding:0;WIDTH: 420px;" align=center><tr><td style="HEIGHT: 20px;margin:0; padding:0;" width="407" valign="bottom">' + ((h1 == '') ? '' : '<font style="margin-LEFT: 12px;FONT-WEIGHT: bold; FONT-SIZE: 12px;COLOR: #000000;">' + h1 + '</font>') + '</td><TD width="13" style="PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px;"><a href="javascript:void(0)" onclick="LR_HideInvite();LR_RefuseChat();return false;"><img src="' + LR_CheckUserUrl(LR_close_img) + '" border="0"></a></TD></tr><TR><TD colspan="2"><table ID="LR_Tb3" style="BORDER-COLLAPSE: collapse;border: ' + LR_invite_color2 + ' 1px solid; background-color: #FFFFFF;margin-left:7px;margin-right:7px;margin-bottom:7px;margin-top:0;WIDTH: 400px;" align=center><tr><td><table cellspacing=0 cellpadding=0 ID="LR_Tb4" align=center style="WIDTH: 400px; HEIGHT: 104px;border:0;margin:0; padding:0;"><tr><td rowspan="2" style="WIDTH: 110px" align=center><img src="' + LR_CheckUserUrl(LR_ivite_img) + '"></td><td style="PADDING-RIGHT: 10px; PADDING-LEFT: 10px; PADDING-BOTTOM: 2px; PADDING-TOP: 19px;FONT-SIZE: 12px;color:' + LR_invite_color3 + ';" align=left valign=top>' + h2 + '</td></tr><tr><td align=right height=30><table border=0 style="margin:0; padding:0;WIDTH: 180px;"><tr><td><img src="' + LR_CheckUserUrl(LR_accept_img) + '" border=0 usemap="#Map93LR" /><map name="Map93LR"><area shape="rect" coords="1,1,78,22"  href="javascript:void(0)" onclick="openZoosUrl();LR_HideInvite();return false;"></map></td><td width=20></td><td><a href="javascript:void(0)" onclick="LR_HideInvite();LR_RefuseChat();return false;"><img src="' + LR_CheckUserUrl(LR_refuse_img) + '" border=0></a></td><td width=20></td></tr></table></td></tr></table></td></tr></table></td></tr></table>';
	}
	LR_Floaters[1].showdiv(0);
	LR_Floaters[1].imageTimer(true);
	if (LR_fade_invite) LR_fadeIn('LRfloater1');
	if (document.body) {
		document.body.appendChild(LR_GetObj('LRdiv0'));
		document.body.appendChild(LR_GetObj('LRdiv1'));
	}
	if (LR_invite_hide_float && LR_showfloat) LR_Floaters[0].hidden();
	window.focus();
	LR_SetCookie('lastshowinvite', new Date().getTime(), 720);
}

function LR_showHfloat() {
	if (LR_invite_hide_float && LR_showfloat) {
		LR_Floaters[0].showdiv(1);
		if (document.body) document.body.appendChild(LR_GetObj('LRdiv0'));
	}
}

function LR_HideInvite() {
	if (LR_Floaters[1].pms['html'] == '') return;
	LR_Floaters[1].pms['html'] = '';
	LR_showHfloat();
	LR_m_f(LR_m_d);
	if (LR_fade_invite) {
		if (LR_GetObj('LRfloater1') == null) return;
		LR_fadeOut('LRfloater1');
	} else {
		LR_Floaters[1].hidden();
	}

	if (LR_istate == 1) {
		LR_istate = 0;
	}
}

function LR_Hidemobileinvite(lid) {
	if (lid != 1) return;
	LR_RefuseChat();
	LR_HideInvite();
}

function LR_SetOpacity(ev, v) {
	ev.filters ? ev.style.filter = 'alpha(opacity=' + v + ')' : ev.style.opacity = v / 100;
}

function LR_fadeIn(elem) {
	if (LR_GetObj(elem) == null) {
		return;
	}
	speed = 120;
	opacity = 100;
	LR_GetObj(elem).style.display = 'block';
	LR_SetOpacity(LR_GetObj(elem), 0);
	var val = 0;
	(function() {
		LR_SetOpacity(LR_GetObj(elem), val);
		val += 5;
		if (val <= opacity) {
			setTimeout(arguments.callee, speed)
		}
	})();
}

function LR_fadeOut(elem) {
	if (LR_GetObj(elem) == null) {
		return;
	}
	speed = 50;
	opacity = 0;
	var val = 100;
	(function() {
		LR_SetOpacity(LR_GetObj(elem), val);
		val -= 5;
		if (val >= opacity) {
			setTimeout(arguments.callee, speed);
		} else if (val <= 0) {
			LR_GetObj(elem).style.display = 'none';
		}
	})();
}
LR_Fid++;
eval('var onlinerIcon' + LR_Fid + '=new OnlinerIcon();');
eval('onlinerIcon' + LR_Fid + '.pms[\'LR_Fid\']=LR_Fid;');
eval('onlinerIcon' + LR_Fid + '.pms[\'show\']=\'none\';');
if (LR_pm015) {
    eval('onlinerIcon' + LR_Fid + '.pms[\'xCenter\']=1;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'yCenter\']=1;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'lr_xCenter\']=' + Math.floor(LR_pm013 / 2)+';');
    eval('onlinerIcon' + LR_Fid + '.pms[\'lr_yCenter\']=' + Math.floor(LR_pm014 / 2)+';');
}
else {
    eval('onlinerIcon' + LR_Fid + '.pms[\'aligny\']=_lr_mfloat_tobottom;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'alignx\']=_lr_mfloat_toright;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'alignW\']=_lr_mfloat_imgleft;');
    eval('onlinerIcon' + LR_Fid + '.pms[\'alignH\']=_lr_mfloat_imgtop;');
}
eval('onlinerIcon' + LR_Fid + '.pms[\'html\']=\'\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'closer_show\']=0;');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRfloater\']=\'LRfloater' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRdiv\']=\'LRdiv' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.start();');
eval('onlinerIcon' + LR_Fid + '.LR_scrollTimer = window.setInterval(\'onlinerIcon' + LR_Fid + '.autoScroll()\', 200); ');
eval('LR_Floaters.push(onlinerIcon' + LR_Fid + ');');
LR_Fid++;
eval('var onlinerIcon' + LR_Fid + '=new OnlinerIcon();');
eval('onlinerIcon' + LR_Fid + '.pms[\'LR_Fid\']=LR_Fid;');
eval('onlinerIcon' + LR_Fid + '.pms[\'show\']=\'none\';');
 eval('onlinerIcon' + LR_Fid + '.pms[\'aligny\']=1;');
eval('onlinerIcon' + LR_Fid + '.pms[\'alignx\']=1;');
eval('onlinerIcon' + LR_Fid + '.pms[\'alignW\']=0;');
eval('onlinerIcon' + LR_Fid + '.pms[\'alignH\']=0;');

eval('onlinerIcon' + LR_Fid + '.pms[\'html\']=\'\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'closer_show\']=0;');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRfloater\']=\'LRfloater' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.pms[\'LRdiv\']=\'LRdiv' + LR_Fid + '\';');
eval('onlinerIcon' + LR_Fid + '.start();');
eval('onlinerIcon' + LR_Fid + '.LR_scrollTimer = window.setInterval(\'onlinerIcon' + LR_Fid + '.autoScroll()\', 200); ');
eval('LR_Floaters.push(onlinerIcon' + LR_Fid + ');');
var lr_winunload = window.onunload;

function lrmove() {
	_lr_mfloat_toright = !_lr_mfloat_toright;
	var LR_o1 = LR_GetObj('LRfloater2').style;
	if (_lr_mfloat_toright == 1) {
		LR_o1.left = '';
		LR_o1.right = _lr_mfloat_imgleft + 'px';
	} else {
		LR_o1.right = '';
		LR_o1.left = _lr_mfloat_imgleft + 'px';
	}
}

function lr_winunload1() {
	if (LR_Floaters[2].pms['show'] != 'none' && LR_Floaters[2].pms['html'] != '') lr_closemini(1);
	if (typeof(lr_winunload) == 'function') {
		lr_winunload();
	}
}
var clickopenmini = 0;
var lr_skdata = '';
function LR_showminiDiv(islrminimin,data) {
	if (LR_chatkind == -1 && !clickopenmini) {
		setTimeout('LR_showminiDiv();', 500);
		return;
	}
	if (LR_chatkind == 111) return;
	if (LR_Floaters[2].pms['html'] == '') {
		window.onunload = lr_winunload1;
	} else {
        if (LR_GetObj('LRMINIWIN').style.display != 'block') lrminiMax();

            return;
	}
	LR_invitew = 200;LR_inviteh = 200;
	if (!islrminimin) LR_SetCookie('LR_mimiwin', LR_Tick, 120);
	if (LR_Floaters[3].pms['html'] == '') {
		LR_Floaters[3].pms['html'] = minibarhtmlF(islrminimin);
	}
	LR_Floaters[2].pms['html'] = minichathtmlF(islrminimin);
	LR_Floaters[2].imageTimer(true);
	LR_Floaters[3].imageTimer(true);
	setTimeout("LR_GetObj('LRMINIWIN0').style.display='block';", 1000);
	lr_mini_blanksrc = islrminimin ? 1 : 0;
	lr_mini_closed = 0;
	setTimeout("LR_Floaters[2].showdiv(0);LR_Floaters[3].showdiv(0);", 300);
	LR_Floaters[1].hidden();
	if (document.body) {
		document.body.appendChild(LR_GetObj('LRdiv2'));
		document.body.appendChild(LR_GetObj('LRdiv3'));
	}
    if (!islrminimin) {
        lr_skdata = data ? data : '';
        setTimeout("LR_miniframe.location=LR_minisrc() + '&msg=' + escape(LR_msg)+lr_skdata;LR_msg='';LR_msg='';", 100);
	}
}


function LR_showminiDiv_of() {
	if (LR_Floaters[3].pms['html'] == '') {
		LR_Floaters[3].pms['html'] = minibarhtmlF(0);
	}
	LR_Floaters[2].pms['html'] = minichathtmlF(0);
	LR_Floaters[2].imageTimer(true);
	LR_Floaters[3].imageTimer(true);
	setTimeout("LR_GetObj('LRMINIWIN0').style.display='block';", 1000);
	lr_mini_blanksrc = 0;
	lr_mini_closed = 0;
	setTimeout("LR_Floaters[2].showdiv(0);LR_Floaters[3].showdiv(0);", 300);
	if (document.body) {
		document.body.appendChild(LR_GetObj('LRdiv2'));
		document.body.appendChild(LR_GetObj('LRdiv3'));
	}
	setTimeout("LR_miniframe.location=LR_minisrc()", 100);
}

function lr_hidemini() {
	if (LR_Floaters[2].pms['html'] != '') {
		window.onunload = lr_winunload;
		LR_Floaters[2].pms['html'] = '';
		clickopenmini = 0;
		LR_Floaters[2].hidden();
	}
}
function LR_hcloopJS(url, param) {
	var me = arguments.callee;
	var src = url.indexOf('?') == '-1' ? url + '?' : url;
	src += param;
	if (src.indexOf('&d=') == '-1') src += '&d=' + new Date().getTime();
	me.Script&&me.Script.parentNode && me.Script.parentNode.removeChild(me.Script);
	me.Script = document.createElement('script');
	me.Script.setAttribute('type', 'text/javascript');
	me.Script.setAttribute('charset', 'utf-8');
	me.Script.src = src;
	if (document.getElementsByTagName('head')[0])
       document.getElementsByTagName('head')[0].appendChild(me.Script);
}

function lr_closemini(nop) {
	if (!LiveReceptionCode_isonline) {
		lr_hidemini();
		lr_mini_closed = 1;
		return;
	}
	if (nop || confirm(LR_confirm_closechat)) {
	    if(autoshowmini_time!=null){clearTimeout(autoshowmini_time);autoshowmini_time=null;}
		lr_hidemini();
		checkcount = -1;
		LR_inviteimgJS = 0;
		LR_hcloopJS(LR_sysurl + 'LR/CdEnd.aspx', 'id=' + LR_siteid + '&m=1&lng=' + LR_lng + '&sid=' + LR_sid);
		lastshowmini = new Date().getTime();
		lr_mini_closed = 1;
		_LR_show2();
	}
}
var lr_mini_blanksrc = 0,
	lr_mini_closed = -1;

function lrminiMin0(nop) {
	if (!lr_mini_blanksrc && nop) {
		window.onunload = lr_winunload;
		LR_miniframe.location = LR_sysurl + 'JS/im2.html';
		clickopenmini = 0;
		lr_mini_blanksrc = 1;
	}
}

function lrminiMin(nop) {
	if (LR_Floaters[2].pms['html'] == '') return;
	if (LR_GetObj('LRMINIBar').style.display == 'block') {
		lrminiMin0(nop);
		return;
	}
	LR_GetObj('LRMINIWIN').style.width = '390px';
	LR_GetObj('LRMINIWIN').style.display = 'none';
	lrminiMin0(nop);
	LR_GetObj('LRMINIBar').style.display = 'block';
	LR_maxoid = 0;
}

function lrminiMax() {
	if (lr_mini_blanksrc) {
		LR_SetCookie('LR_mimiwin', LR_Tick, 120);
		LR_miniframe.location = LR_minisrc();
		lr_mini_blanksrc = 0;
		window.onunload = lr_winunload1;
		
	}
	if (LR_GetObj('LRMINIWIN') == null || LR_GetObj('LRMINIWIN').style.display != 'none') return;
	LR_GetObj('LRMINIWIN').style.display = 'block';
    LR_GetObj('LRMINIWIN').style.width = LiveReceptionCode_isonline ? LR_pm013+'px' : '420px';
	LR_GetObj('LRMINIBar').style.display = 'none';
	
	lr_newcount=0;
	if(LR_GetObj('LR-CIRCLE'))
	{
	LR_GetObj('LR-CIRCLE').style.display='none';
	LR_GetObj('LR-BUBBLE').style.display='none';
	}
}
if (typeof(LrinviteTimeout) == 'undefined' || isNaN(LrinviteTimeout) || LrinviteTimeout < 1) {
	LrinviteTimeout = 1;
}
if (!_lr_issupport_track && (LiveReceptionCode_isonline || !offline_invite_hidden)) {
	LR_nextinvite(1);
}

function getFlashMovieObject(movieName) {
	if (window.document[movieName]) {
		return window.document[movieName];
	}
	if (navigator.appName.indexOf('Microsoft Internet') == -1) {
		if (document.embeds && document.embeds[movieName]) return document.embeds[movieName];
	} else {
		return document.getElementById(movieName);
	}
}



function lr_refer5238() {
	if (typeof(lr_refer5236) != 'undefined') {
		return '&r=' + escape(lr_refer5236);
	}
	var lr_refer5235 = LR_getCookie('lr_refer5');
	if (lr_refer5235 != null) {
		LR_SetCookie('lr_refer5', '', -60);
		return '&r=' + lr_refer5235;
	}
	var ur = document.referrer;
	var i = ur.lastIndexOf('.');
	return '&rf1=' + escape(ur.substring(0, i)) + '&rf2=' + escape(ur.substr(i));
}

function openZoosUrl(url, data) {
	if (typeof(openZoosUrl_UserDefine) == 'function') {
		if (openZoosUrl_UserDefine()) return;
	};
	if (typeof(LR_istate) != 'undefined') {
		LR_istate = 3;
	}
	var lr_url1 = url;
	if (typeof(LR_opentimeout) != 'undefined' && typeof(LR_next_invite_seconds) != 'undefined') LR_next_invite_seconds = 999999;
	if (url == 'sendnote') {
		url = LR_sysurl + 'LR/Chatwin2.aspx?siteid=' + LR_websiteid + '&cid=' + LR_cid + '&sid=' + LR_sid + '&lng=' + LR_lng + '&p=' + escape(location.href) + lr_refer5238();
	} else {
		url = ((LR_userurl0 && typeof(LR_userurl) != 'undefined') ? LR_userurl : (LR_sysurl + 'LR/Chatpre.aspx')) + '?id=' + LR_websiteid + '&cid=' + LR_cid + '&lng=' + LR_lng + '&sid=' + LR_sid + '&p=' + escape(location.href) + lr_refer5238();
	}
	if (typeof(LR_UserSSL) != 'undefined' && LR_UserSSL && url.charAt(4) == ':') url = url.substring(0, 4) + 's' + url.substring(4, url.length);
	if (!data) {
		if (typeof(LR_explain) != 'undefined' && LR_explain != '') {
			url += '&e=' + escape(escape(LR_explain));
		} else if (typeof(LiveAutoInvite1) != 'undefined') {
			url += '&e=' + escape(escape(LiveAutoInvite1));
		}
	}
	if (typeof(LR_username) != 'undefined') {
		url += '&un=' + escape(LR_username);
	}
	if (typeof(LR_userdata) != 'undefined') {
		url += '&ud=' + escape(LR_userdata);
	}
	if (typeof(LR_ucd) != 'undefined') {
		url += '&ucd=' + escape(LR_ucd);
	}
    url += '&msg=' + escape(LR_msg);
    LR_msg = '';
	if (data) url += data;
	url += '&d=' + new Date().getTime();
	if (typeof(LR_imgint) != 'undefined') url += '&imgint=' + LR_imgint;
	if (lr_url1 == 'fchatwin') {
		LR_ClientEnd = 0;
		window.location = url + '&f=1';
		return;
	}
	if (LR_sidexists != 2 && LiveReceptionCode_isonline && lr_url1 != 'bchatwin' && typeof(LR_pm003) != 'undefined' && LR_pm003 == 1) {
		LR_HideInvite();
		LR_istate = 1;
		clickopenmini = 1;
        LR_showminiDiv(0, data);
		lrminiMax();
		return;
	}

	var oWindow;
	try {
		if (LR_checkagent('opera|safari|se 2.x')) {
			oWindow = window.open(url);
		} else {
			oWindow = window.open(url, 'LRWIN_' + LR_websiteid, 'toolbar=no,width=760,height=460,resizable=yes,location=no,scrollbars=no,left=' + ((screen.width - 760) / 4) + ',top=' + ((screen.height - 460) / 4));
		}
		if (oWindow == null) {
			LR_ClientEnd = 0;
			window.location = url;
			return;
		}
		oWindow.focus();
	} catch (e) {
		if (oWindow == null) {
			LR_ClientEnd = 0;
			window.location = url;
		}
	}
}
if (LR_hasInstall > 0 && typeof(LR_swfok) == 'undefined') {
	var LR_swfok = 1;
	document.write('<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="' + LR_sysurl.substring(0, LR_sysurl.indexOf('//')) + '//fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width=0 height=0 style="width: 0px; height: 0px; position: absolute;" id="LR_Flash" class="noswap"><param name=movie value="' + LR_sysurl + 'js/lrfla.swf"><PARAM NAME="BGColor" VALUE="FFFFFF"><param name=quality value=high><PARAM NAME="Scale" VALUE="NoBorder"><param name="allowScriptAccess" value="always" />' + (LR_hasInstall > 1 ? '' : '<embed src="' + LR_sysurl + 'js/lrfla.swf" style="width: 0px; height: 0px; position: absolute;"  quality=high width=0 height=0 type="application/x-shockwave-flash" pluginspage="' + LR_sysurl.substring(0, LR_sysurl.indexOf('//')) + '//www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash" name="LR_Flash" allowScriptAccess="always"></embed>') + '</object>');
	try {
		document.write('<script language=\"VBScript\"\>\n');
		document.write('On Error Resume Next\n');
		document.write('Sub LR_Flash_FSCommand(ByVal command, ByVal args)\n');
		document.write('	Call LR_Flash_DoFSCommand(command, args)\n');
		document.write('End Sub\n');
		document.write('</SCRIPT\>');
	} catch (e) {}
	var LR_SaveTime = null;

	function LR_savedata(data, name) {
		if (LR_swfok) {
			LR_SaveTime = setTimeout('LR_savedata("' + data + '","' + name + '")', 5);
			return;
		}
		LR_swfok = 1;
		try {
			getFlashMovieObject('LR_Flash').SetVariable('send_type', 'SAVEDATA');
			getFlashMovieObject('LR_Flash').SetVariable('send_name', 'save');
			getFlashMovieObject('LR_Flash').SetVariable('send_vars', data);
			getFlashMovieObject('LR_Flash').SetVariable('obname', name);
			getFlashMovieObject('LR_Flash').SetVariable('send_go', 'true');
		} catch (e) {}
	}
	var LR_ReadTime = null;

	function LR_readdata(name) {
		if (LR_swfok) {
			LR_ReadTime = setTimeout('LR_readdata("' + name + '")', 50);
			return;
		}
		LR_swfok = 1;
		try {
			getFlashMovieObject('LR_Flash').SetVariable('send_type', 'READDATA');
			getFlashMovieObject('LR_Flash').SetVariable('send_name', 'read');
			getFlashMovieObject('LR_Flash').SetVariable('obname', name);
			getFlashMovieObject('LR_Flash').SetVariable('send_go', 'true');
		} catch (e) {}
	}
	var LR_swfloadok = 1;
	var LR_testload = 0;

	function LR_loadok() {
		if (LR_swfloadok) {
			LR_testload++;
			if (LR_testload == 20) {
				LR_SetCookie('LR_hasInstall', 0, 60);
				LR_hasInstall = 0;
				LR_useCookie();
				if (LR_swf_timeid != null) {
					clearInterval(LR_swf_timeid);
					LR_swf_timeid = null;
				}
				return;
			}
			try {
				getFlashMovieObject('LR_Flash').SetVariable('send_type', 'LOADOK');
				getFlashMovieObject('LR_Flash').SetVariable('send_go', 'true');
			} catch (e) {}
		} else {
			if (LR_swf_timeid != null) {
				clearInterval(LR_swf_timeid);
				LR_swf_timeid = null;
			}
		}
	}
	var LR_swf_timeid = null;
	if (LR_hasInstall > 0) LR_swf_timeid = setInterval('LR_loadok();', 100);
}
if (typeof(LR_Flash_DoFSCommand) != 'function') {
	function floatdata_append(_data, add) {
		if (_data != '') {
			_data += '|';
		}
		return _data += add;
	}

	function LR_Flash_DoFSCommand(command, args) {
		if (command == "LOADOK") {
			if (!LR_swfloadok) return;
			LR_swfloadok = 0;
			LR_swfok = 0;
			return;
		}
		if (command == "save") {
			if (args == 'true') {
				LR_swfok = 0;
				return;
			} else {}
			LR_swfok = 0;
		}
		if (command == "read") {
			var lrdata = '';
			if (args == '') {
				LR_readdata(LR_websiteid);
				LR_swfok = 0;
				return;
			} else if (args == '|') {} else {
				var oo = args.split('|');
				for (o = 0; o < oo.length; o++) {
					var oo1 = oo[o].split(',');
					if (oo1.length == 2) {
						if (isNaN(oo1[1])) {
							var v = 'if(typeof(LR_' + oo1[0] + ') != "undefined"){LR_' + oo1[0] + '=unescape(oo1[1]);}';
							eval(v);
						} else {
							eval('if(typeof(LR_' + oo1[0] + ') != "undefined"){LR_' + oo1[0] + '=oo1[1];}');
						}
					}
				}
			}
			if (LR_cid == '' || LR_cid == 'null') LR_cid = null;
			if (LR_sid == '' || LR_sid == 'null') LR_sid = null;
			if (LR_cid == null || LR_sid == null) {
				LR_cid = LR_getCookie('LiveWS' + LR_websiteid);
				LR_sid = LR_getCookie('LiveWS' + LR_websiteid + 'sessionid');
				lrdata = floatdata_append(lrdata, 'cid,' + LR_cid + '|sid,' + LR_sid + '|fistvisitetime,' + new Date().getTime() + '|lastvisitetime,' + new Date().getTime() + '|visitecounts,1|visitepages,1');
			} else {
				lrdata = floatdata_append(lrdata, 'lastvisitetime,' + new Date().getTime() + '|visitepages,' + (parseInt(LR_visitepages) + 1));
				if ((new Date().getTime() - parseInt(LR_lastvisitetime)) > 43200000) {
					LR_sid = LR_getCookie('LiveWS' + LR_websiteid + 'sessionid');
					lrdata = floatdata_append(lrdata, 'sid,' + LR_sid + '|visitecounts,' + (parseInt(LR_visitecounts) + 1));
				}
				LR_swfok = 0;
				if (lrdata != '') {
					LR_savedata(lrdata, LR_websiteid);
				}
			}
			LR_addnew0();
		}
	}
}

function LR_useCookie() {
	LR_cid = LR_getCookie('LiveWS' + LR_websiteid);
	LR_sid = LR_getCookie('LiveWS' + LR_websiteid + 'sessionid');
	LR_fistvisitetime = LR_getCookie('fistvisitetime');
	LR_lastvisitetime = LR_getCookie('lastvisitetime');
	LR_visitecounts = LR_getCookie('visitecounts');
	LR_visitepages = LR_getCookie('visitepages');
	LR_cname = LR_getCookie('cname');
	LR_ccolor = LR_getCookie('ccolor');
	if (LR_fistvisitetime == null) {
		LR_SetCookie('fistvisitetime', new Date().getTime(), 2628000);
		LR_SetCookie('lastvisitetime', new Date().getTime(), 2628000);
		LR_SetCookie('visitecounts', 1, 2628000);
		LR_SetCookie('visitepages', 1, 2628000);
	} else {
		LR_SetCookie('lastvisitetime', new Date().getTime(), 2628000);
		if ((new Date().getTime() - parseInt(LR_lastvisitetime)) > 43200000) {
			LR_SetCookie('visitecounts', (parseInt(LR_visitecounts) + 1), 2628000);
		}
		LR_SetCookie('visitepages', (parseInt(LR_visitepages) + 1), 2628000);
	}
	LR_addnew0();
}
if (LR_hasInstall > 0) {
	LR_readdata(LR_websiteid)
} else {
	LR_useCookie();
};

function LiveReceptionCode_BuildChatWin(_lrchatexplain, _lrhelpalt) {
	return ' href="javascript:void(0)"  onclick="openZoosUrl(\'chatwin\',\'&e=' + escape(escape(_lrchatexplain)) + '\');return false;" title="' + unescape(_lrhelpalt) + '" target="_self" ';
}

function LR_GetAutoInvite2() {
	if (LR_invitesearchkey && LR_skey != null && typeof(LiveAutoInvite3) != 'undefined') {
		return LiveAutoInvite3.replace('%SKEY%', unescape(LR_skey));
	} else if (LR_invitestring1_auto != '') {
		return LR_invitestring1_auto;
	} else {
		return LiveAutoInvite2.replace(/\\"/g, '"');
	}
}

function clearinviteTimeout() {
	if (LR_nexttimerID != null) {
		clearTimeout(LR_nexttimerID);
		LR_nexttimerID = null;
	}
	LR_HideInvite();
}

function LR_invitef() {
	if (LR_invite0 == 'fopenchatwin') {
		LR_gstate = 1;
		if (LR_istate < 2) {
			clearinviteTimeout();
			LR_istate = 2;
			window.focus();
			lr_hidemini();
			openZoosUrl('fchatwin');
		}
	} else if (LR_invite0 == 'no') {
		LR_gstate = 2;
		clearinviteTimeout();
		if (LR_istate > 0) {
			LR_istate = 0;
		}
	} else if (LR_invite0 == 'openchatwin') {
		LR_gstate = 1;
		if (LR_istate > -1) {
			clearinviteTimeout();
			LR_istate = 1;
			LR_showminiDiv();
		}
	} else if (LR_invite0 != '') {
		LR_gstate = 1;
		if (LR_istate > -1) {
			clearinviteTimeout();
			LR_istate = 1;
			LR_showInviteDiv(LR_invite0, LR_invite1);
		}
	}
}

function LR_IPCB(_lrip) {
    if(_lrip.status==0)
    {
        LR_hcloopJS(LR_sysurl + 'LS/newsidip.aspx', 'id=' + LR_siteid + '&sid=' + LR_sid + '&lng=' + _lrip.result.location.lng + '&lat=' + _lrip.result.location.lat + '&nation=' + encodeURIComponent(_lrip.result.ad_info.nation) + '&province=' + encodeURIComponent(_lrip.result.ad_info.province) + '&city=' + encodeURIComponent(_lrip.result.ad_info.city));
    }
}
function LR_LS() {
	if (LR_sidexists == -1) {
		setTimeout('LR_LS()', 100);
		return;
	}
	LR_Check_region();
	if (LR_invite0 == 'alerturl') {
		var oo5 = LR_invite1.split(',');
		alert(unescape(oo5[1]));
		window.location = oo5[0];
	} else if (LR_invite0 == 'url') {
		window.location = LR_invite1;
	} else if (LR_invite0 == 'alert') {
		alert(LR_invite1);
		LR_gstate = -2;
	}

	function LRedithref(pm, pv, href) {
		if (href.indexOf(pm) == -1) href += pm + pv;
		return href;
	}
	function LRedithref1() {
		var aList = document.getElementsByTagName('a');
		for (var i = 0; i < aList.length; i++) {
			var href0 = aList[i].href.toLowerCase();
			if (href0 && /chatpre.aspx|chatwin.aspx/.test(href0) && href0.indexOf('=' + LR_websiteid.toLowerCase()) > -1) {
				href0 = LRedithref('&r=', lr_refer5238(), href0);
				href0 = LRedithref('&p=', escape(location.href), href0);
				href0 = LRedithref('&cid=', LR_cid, href0);
				href0 = LRedithref('&sid=', LR_sid, href0);
				aList[i].href = href0;
			}
		}
	}
	LRedithref1();
	if (_lr_issupport_track) {
		if (LR_sidexists == 0) {
			var LR_Color = 16;
			if (navigator.appName != 'Netscape') {
				LR_Color = screen.colorDepth;
			} else {
				LR_Color = screen.pixelDepth;
			}
			
			var data = 'id=' + LR_siteid + '&sid=' + LR_sid + '&s=' + LR_sSize + '&ft=' + LR_fistvisitetime + '&fl=' + LR_lastvisitetime + '&vc=' + LR_visitecounts + '&vp=' + LR_visitepages + '&c=' + LR_Color + '&lng=' + LR_lng + '&cid=' + LR_cid + '&z=' + (new Date()).getTimezoneOffset() / 60;
			data += '&cn=' + escape(LR_cname) + '&co=' + escape(LR_ccolor);
			checkcount = -1;
			LR_inviteimgJS = 0;
			LR_hcloopJS(LR_sysurl + 'LS/newsid0.aspx', data);
			if(typeof(LR_IPTK) != 'undefined')
			{
			    data = 'ip='+LR_ip+'&key='+LR_IPTK+'&output=jsonp&callback=LR_IPCB';
			    LR_hcloopJS('http' + (LR_ssl ? 's' : '') + '://apis.map.qq.com/ws/location/v1/ip', data);
			}
		}
	}
	if (!LiveReceptionCode_isonline) {
        if (LR_pm004 && _lr_issupport_track) LR_showminiDiv_of();
        if (offline_invite_hidden)return;
	}
	LR_invitef();
	if (_lr_issupport_track) LR_nextinvite(1);
	if (LR_sidexists == 2) return;
	if (LiveReceptionCode_isonline && _lr_issupport_track) {
		LR_hcloop();
	}
}
LR_LS();
function lronunload1() {
	if (!LR_ClientEnd) return;
	LR_ClientEnd = 0;
	LR_inviteimgJS = 0;
	LR_hcloopJS(LR_sysurl + 'LR/ClientEndJS.aspx', 'id=' + LR_siteid + '&lng=' + LR_lng + '&sid=' + LR_sid);
	try {
		if (typeof(lronunload0) == 'function') lronunload0();
	} catch (e) {}
}
var lronunload0 = window.onunload;
window.onunload = lronunload1;


function LR_nextinvite(fic) {
	if (LR_gstate < 1 && LR_istate == 0 && typeof(LiveAutoInvite0) != 'undefined') {
		if (!fic && (!LR_repeatinvite || typeof(LR_next_invite_seconds) == 'undefined')) return;
		var lastshowinvite = parseInt(LR_getCookie('lastshowinvite'));
		if (isNaN(lastshowinvite)) {
			lastshowinvite = 0;
		}
		var intimeout = _lr_invite_interval * 1000 - (new Date().getTime() - lastshowinvite);
		var intimeout1 = (fic ? LrinviteTimeout : LR_next_invite_seconds) * 1000;
		if (intimeout > 0) {
			intimeout1 += intimeout;
		}
		LR_istate = 1;
		LR_nexttimerID = setTimeout('LR_showInviteDiv("1","1")', intimeout1);
	}
}
function LR_RefuseChat() {
	if (LR_gstate == 1) {
		LR_invite0 = '';
		LR_istate = -1;
	}
	LR_nextinvite();
}





function _LR_show2(_lrshow) {
	if (lr_mini_closed!=1) return;
	if (typeof(LR_nextshowmini_s) != 'undefined' && !isNaN(LR_nextshowmini_s) && new Date().getTime() - lastshowmini > LR_nextshowmini_s * 1000) {
		LR_showminiDiv(_lrshow);
	}
}

function LR_CheckImgJS(w, w1, w2, w3) {
	LR_inviteimgJS = 1;
	if (!LR_cookie_test || w == 2) {
		LR_CheckImgJS1(w, w1, w2, w3);
		return;
	}
	var w0 = w + '|' + new Date().getTime() + '|' + (w1 ? w1 : '') + '|' + (w2 ? w2 : '') + '|' + (w3 ? w3 : '');
	LR_SetCookie('LR_check_data', w0, 0.1);
}

function LR_CheckImgJS1(w, w1, w2, w3) {
	if (!w) {
		return;
	}
	if (w == 28) {
		return;
	}
	if (checkcount == -1 && w != 6) return;
	if (w > 0) {
		if (LR_chatkind == -1) LR_chatkind = 0;
		if (w == 2) {
			LR_gstate = 1;
			if (LR_istate < 2) {
				clearinviteTimeout();
				LR_istate = 2;
				window.focus();
				lr_hidemini();
				openZoosUrl('fchatwin');
			}
		} else if (w == 8) {
			LR_gstate = 1;
			if (LR_istate > -1) {
				clearinviteTimeout();
				LR_istate = 1;
				if (w1) LR_chatkind = w1;
				LR_showminiDiv();
			}
		} else if (w == 4) {
			LR_gstate = 0;
			if (LR_istate > 1) {
				LR_istate = 0;
			}
			LR_nextinvite();
			if (LR_chatkind) {
				LR_chatkind = 0;
				lastshowmini = new Date().getTime();
				lr_mini_closed = 1;
			}
			_LR_show2(0);
		} else if (w == 5) {
			if (LR_gstate != 2) {
				LR_gstate = 2;
				LR_SetCookie('LR_lastchat', '1', 720);
			}
			clearinviteTimeout();
			if (LR_istate > 0) {
				LR_istate = 0;
			}
			if (w1) LR_chatkind = w1;
			if (w1 == 111) lr_hidemini();
			if (lr_mini_closed==1) return;
			if (w1 == 2 && LR_GetObj('LRMINIBar') == null) {
				LR_HideInvite();
				LR_istate = 1;
				LR_showminiDiv();
			}
			if (w2) LR_maxoid = w2;
			if (IEmsg && w3 && LR_getCookie('LR_mimiwin') == LR_Tick) lrminiMax();
		} else if (w == 7) {
			LR_gstate = -1;
			if (LR_istate > 1) {
				LR_istate = 0;
			}
			LiveReceptionCode_isonline = 0;
			if (typeof(LR_offline) == 'function') LR_offline();
			LR_Floaters[0].pms['html'] = LR_buildfloat();
			LR_Floaters[0].imageTimer(true);
			return;
		} else if (w == 1) {
			if (LR_gstate == 1) return;
			checkcount = 2;
			LR_invite0 = w1;
			LR_invite1 = w2;
			LR_invitef();
		}
	}
}

function LR_hcloop() {
	if (!LiveReceptionCode_isonline || !_lr_issupport_track || (LR_visitetime + 1800000) < new Date().getTime()) return;
	if (LR_cookie_test) {
		if (LR_getCookie('LR_mimiwin') != LR_Tick && LR_chatkind == 2 && !clickopenmini) lrminiMin(1);
		var LR_check_data = LR_getCookie('LR_check_data');
		if (LR_check_data != null) {
			var LR_ss = LR_check_data.split("|");
			if (LR_ss.length > 4 && LR_cookie_ctick < parseInt(LR_ss[1])) {
				LR_cookie_ctick = parseInt(LR_ss[1]);
				LR_CheckImgJS1(LR_ss[0], LR_ss[2], LR_ss[3], LR_ss[4]);
				setTimeout('LR_hcloop()', 500);
				return;
			}
		}
	}
	if (checkcount == -1 || !LR_inviteimgJS) {
		setTimeout('LR_hcloop()', 500);
		return;
	}
	if (LR_istate == -1) {
		LR_istate = -2;
		checkcount = -1;
		LR_inviteimgJS = 0;
		LR_hcloopJS(LR_sysurl + 'JS/RefuseChatjs.aspx', 'id=' + LR_siteid + '&sid=' + LR_sid + '&lng=' + LR_lng);
		setTimeout('LR_hcloop()', 500);
		return;
	}
	if (LR_cookie_test && LR_getCookie('lastinvite') != null) LR_lastinvite = LR_getCookie('lastinvite');
	if (LR_lastinvite != null) {
		if (LR_MCount1 < 5000) LR_MCount1 = 5000;
		if ((new Date().getTime() - parseInt(LR_lastinvite)) > LR_MCount1) {
			LR_lastinvite = new Date().getTime();
			LR_SetCookie('lastinvite', LR_lastinvite, 720);
			LR_inviteimgJS = 0;
			var url = '';
            if (LR_explain != '') {
                if (LR_msg != '' && LR_explain.indexOf(LR_msg) > -1 && LR_lng == 'cn')
                { }
                else {
                    url = '&e=' + escape(escape(LR_explain));
                    LR_explain = '';
                }
            }
			LR_hcloopJS(LR_sysurl + 'js/CdCheck.aspx', 'id=' + LR_siteid + '&sid=' + LR_sid + url + ((LR_GetObj('LRMINIWIN') != null && LR_GetObj('LRMINIWIN').style.display == 'none') ? ('&oid=' + LR_maxoid) : ''));
		}
	}
	setTimeout('LR_hcloop()', 500);
}
var autoshowmini_time=null;
function LR_showminiDiv2() {
	if (typeof(LR_showminiDiv_no) != 'undefined' || !LR_pm001 || !LiveReceptionCode_isonline || !LR_pm002 || LR_sidexists == 2) return;
	if (LR_cid == null) {
		setTimeout('LR_showminiDiv2();', 300);
		return;
	}
	autoshowmini_time=setTimeout('LR_HideInvite();LR_istate=1;LR_showminiDiv();', typeof(LR_showminiDivtimeout) != 'undefined' ? LR_showminiDivtimeout * 1000 : 2000);
	return;
}
LR_showminiDiv2();


}
