(function() {
	window.BMap_loadScriptTime = (new Date).getTime();
	document.write('<script type="text/javascript" src="http://api.map.baidu.com/getscript?v=2.0&ak=qtrXix5726i83uCCXmQ7aKPOKUVeZeyZ&services=&t=20200327103013"></script>');
})();

$(document).ready(function() {
	//创建地图
	var myMap = new BMap.Map('baiduMap');
	var point = new BMap.Point(113.26444, 23.05686);
	myMap.centerAndZoom(point, 18);

	//添加覆盖物

	var myIcon = new BMap.Icon("static/image/map.png", new BMap.Size(30, 30));
	var marker2 = new BMap.Marker(point, {
		icon: myIcon
	});
	myMap.addOverlay(marker2); // 将标注添加到地图中

	//添加控件
	myMap.addControl(new BMap.NavigationControl()); // 平移缩放
	myMap.addControl(new BMap.OverviewMapControl()); //缩略地图
	myMap.enableScrollWheelZoom(); //滚轮缩放

	if($(window).width() < 768) {
		var ua = navigator.userAgent.toLowerCase(); //获取判断用的对象
		if(ua.match(/MicroMessenger/i) == "micromessenger") { //在微信中打开
			$('.baidumapwx').css('display', 'block');
			$('.baidumapwx').click(function() {
				alert('请通过浏览器打开');
				return false;
			})
		} else {
			$('.baidumapapp').css('display', 'block');
		}
	}
})