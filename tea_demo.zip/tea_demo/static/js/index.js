						var obj = $('.f1'),
							obj2 = $('.f2'),
							html = '';

						function csh(i) {
							//alert(obj2.find('li').eq(i+3).size());
							html = '<li d-t="' + i + '">' + obj2.find('li').eq(i).html() + '</li>';
							if(obj2.find('li').eq(i + 1).size() > 0) html += '<li d-t="' + (i + 1) + '">' + obj2.find('li').eq(i + 1).html() + '</li>';
							if(obj2.find('li').eq(i + 2).size() > 0) html += '<li d-t="' + (i + 2) + '">' + obj2.find('li').eq(i + 2).html() + '</li>';
							if(obj2.find('li').eq(i + 3).size() > 0 && obj2.find('li').eq(i + 4).size() != 0) html += '<li>...</li>';
							if(obj2.find('li').eq(i + 4).size() > 0) html += '<li d-t="n">' + obj2.find('li').last().html() + '</li>';
							obj.html(html);
							obj.find('li').eq(0).click();
						}

						function res(no) {
							if(no < 0) return false;
							if(no > obj2.find('li').size() - 1) return false;
							csh(no);
						}

						$('body').on('click', '.f1 li', function() {
							var i = $(this).attr('d-t');
							$('.tttt').hide();
							if(!i) {
								var n = obj.find('li').eq(2).attr('d-t');
								res(n);
							} else {
								obj.find('li').removeClass('on');
								$(this).addClass('on')
								if(i == 'n')
									$('.tttt').last().show();
								else
									$('.tttt').eq(i).show();
							}
						})
						$('.lh-jour-btn a').click(function() {
							var o = obj.find('li.on');
							if(!o) obj.find('li').eq(0);
							var no = o.attr('d-t');
							if($(this).hasClass('l')) { //zuo
								no--;
							} else {
								no++;
							}
							res(no);
							return false;
						})
						csh(0);

						$(function() {
							//轮播
							var mySwiper = new Swiper('.swiper-container', {
								autoplay: 5000,
								pagination: '.swiper-hd',
								paginationClickable: true,
								paginationBulletRender: function(swiper, index, className) {
									return '<li class="' + className + '"><i class="iconfont icon-ban' + index + '"></i><span></span></li>';
								}
							})
							/*Public.Banner({boxCell:'.lh-jour-tab',mainCell:'.hd1',prevCell:'.prev1',nextCell:'.next1',vis:5,pnLoop:false,autoPlay:false});
							Public.Tab({mainCell:'.bd1',titCell:'.hd1 li',effect:'leftLoop'});//tab*/
							//愿景切换
							var effect = 'topLoop',
								num = 2;
							if($(window).width() <= 768) {
								effect = 'leftLoop';
								num = 1;
							} else {
								jQuery(".lh-vision-tab .bd li").first().before(jQuery(".lh-vision-tab .bd li").last());
							}
							jQuery(".lh-vision-tab").slide({
								mainCell: ".bd",
								effect: effect,
								autoPlay: false,
								vis: 3,
								autoPage: true,
								trigger: "click",
								endFun: function(i, e) {
									$('.lh-vision-bd li').removeClass('active').eq(i + num).addClass('active');
								}
							});
							//爆料
							if($(window).width() <= 768) {
								Public.mobBanner();
							} else {
								Public.Banner({
									boxCell: '.lh-delicay-item',
									autoPlay: false,
									vis: 6,
									pnLoop: false
								});
							}
							//合作伙伴
							var mySwiper = new Swiper('.lh-partner-banner', {
								autoplay: 5000,
								pagination: '.swiper-hd1',
								paginationClickable: true,
							})
							$('.lh-delicay-bd li').hover(function() {
								var _this = $(this);
								var _width = _this.parent().width() + 200;
								_this.parent().width(_width);
							});
						})